import sys
import copy
import datetime
from datetime import datetime as dt

from pypws.entities import DischargeParameters
from pypws.calculations import VesselLeakCalculation, VesselCatastrophicRuptureCalculation
from pypws.calculations import _VesselLeakCalculationRequest, _VesselLeakCalculationRequestSchema
from pypws.calculations import _VesselCatastrophicRuptureCalculationRequest, _VesselCatastrophicRuptureCalculationRequestSchema
from pypws.enums import FlashAtOrifice, ResultCode

from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.calcs import helpers

class Phast_Discharge:

    def __init__(self, leak, state, material, vessel, mi, flashresult, chems = None, flash_at_orifice_allowed = True):
        
        self.leak = leak
        self.state = state
        self.material = material
        self.vessel = vessel
        self.chems = chems
        self.mi = mi
        self.flashresult = flashresult
        self.catastrophic_release = self.mi.CATASTROPHIC_VESSEL_FAILURE
        self.flash_at_orifice_allowed = flash_at_orifice_allowed
        self.prep_vessel_leak_calc()

    def prep_vessel_leak_calc(self):

        self.discharge_parameters = DischargeParameters()
        self.discharge_parameters.flash_at_orifice = FlashAtOrifice.FLASH_ALLOWED
        
        if not self.flash_at_orifice_allowed:
            self.discharge_parameters.flash_at_orifice = FlashAtOrifice.DISALLOW_LIQUID_FLASH

        if self.catastrophic_release:
            self.vesselLeakCalculation = VesselCatastrophicRuptureCalculation(vessel=None, discharge_parameters=self.discharge_parameters)
            calc_request = (
                _VesselCatastrophicRuptureCalculationRequest,
                _VesselCatastrophicRuptureCalculationRequestSchema,
            )

            # per pws documentation, a cat release sets the height of the release point to the midpoint of tank height.  
            # adjusting height to bottom of vessel to match mid-point of vessel to release elevation.

            vessel = copy.deepcopy(self.vessel)
            x = self.mi.RELEASE_ELEVATION_M
            h = vessel.height
            vessel.location.z = x - h/2
            self.vessel = copy.deepcopy(vessel)

            calc_request_obj = calc_request[0]
            calc_request_data  = calc_request_obj(self.vessel, self.discharge_parameters)
            calc_schema_obj = calc_request[1]
            schema = calc_schema_obj()
            request_json = schema.dumps(calc_request_data)

        else:
            self.vesselLeakCalculation = VesselLeakCalculation(vessel=None, leak=self.leak, discharge_parameters=self.discharge_parameters)
            calc_request = (
                _VesselLeakCalculationRequest,
                _VesselLeakCalculationRequestSchema,
            )

            calc_request_obj = calc_request[0]
            calc_request_data  = calc_request_obj(self.vessel, self.leak, self.discharge_parameters)
            calc_schema_obj = calc_request[1]
            schema = calc_schema_obj()
            request_json = schema.dumps(calc_request_data)



        self.vesselLeakCalculation.vessel = self.vessel
        self.vesselLeakCalculation.request_json_tt = request_json

    def run(self, attempts = 1):
        resultCode = ResultCode.FAIL_EXECUTION
        self.dischargeCalcOK = False
        t0 = dt.now(datetime.UTC)
        self.mi.LOG_HANDLER(f'\n**********\n\nInitiating Model: Discharge Calculation.\n')
        for i in range(5):
            try:
                resultCode = self.vesselLeakCalculation.run()

                t1 = dt.now(datetime.UTC)
                runtime = t1-t0
                runtime = runtime.total_seconds()
                self.mi.LOG_HANDLER(f'Model: Discharge Calculation.  Runtime: {runtime} sec. Current time: {t1} UTC. Status: Completed OK.')
                self.dischargeCalcOK = True
            except:
                continue
            break
        
        if resultCode != ResultCode.SUCCESS:
            if hasattr(self.vesselLeakCalculation, "operation_id"):
                self.mi.LOG_HANDLER(f"Vessel Leak Calculation.  \n\nOperation ID {self.vesselLeakCalculation.operation_id}.")
            if hasattr(self.vesselLeakCalculation, "messages"):
                self.mi.LOG_HANDLER(f"\n\nThe following error messages were reported: \n\n{self.vesselLeakCalculation.messages}\n\n")
            if attempts < 2:
                attempts += 1
                self.mi.LOG_HANDLER("Attempting to run Discharge Calculation with liquid flash disallowed at orifice.")
                self.vesselLeakCalculation.discharge_parameters.flash_at_orifice = FlashAtOrifice.DISALLOW_LIQUID_FLASH
                self.run()
                return
            raise Exception(Exception_Enum.DISCHARGE_CALCULATION_ERROR)