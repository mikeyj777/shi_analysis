import sys
import math
import pandas as pd

from pypws.entities import FlashResult, Material, MaterialComponent, State, Leak, Weather, Bund, Phase
from pypws.entities import MixtureModelling, Vessel, Substrate
from pypws.calculations import FlashCalculation
from pypws.enums import AtmosphericStabilityClass, PropertyTemplate, FluidSpec, ResultCode, WindProfileFlag
from pypws.enums import VesselShape, TimeVaryingOption, SurfaceType, PoolSurfaceType
from pypws.materials import *

from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts, Wx_Enum
from py_lopa.classes.vessel_sizing import Vessel_Sizing

consts = Consts()

ra = consts.RELEASE_STREAM_ATTRIBS

def prep_material(chems = None, chem_names = [], mat_ids = [], cas_ids = [], release_molfs = [], cheminfo = None):
    
    if chems is not None:
        df_release = chems.releasing_stream_chem_data
        chem_names = df_release[ra.CHEM_NAME].to_list()
        mat_ids = df_release[ra.MATERIAL_COMPONENT_ID].to_list()
        cas_ids = df_release[ra.CAS_NO].to_list()
        release_molfs = df_release[ra.MOLE_FRACT].to_list()
        cheminfo = chems.cheminfo
    
    if len(chem_names) == 0 and len(cas_ids) == 0:
        raise Exception(Exception_Enum.INVALID_FLASH_INPUTS)
    if len(chem_names) == 0:
        chem_names = helpers.get_chem_names(cas_ids)

    if len(mat_ids) == 0:
        mat_ids = helpers.get_material_ids(chem_mix=cas_ids, cheminfo=cheminfo)

    mat_comps = []
    max_iter = 5
    for i in range(len(chem_names)):
        iter = 0
        connection_error = True
        mc:MaterialComponent
        keep_trying = True
        iter = 0
        while keep_trying:
            iter += 1
            keep_trying = False
            try:
                if pd.isna(mat_ids[i]):
                    mc = get_component_by_cas_id(cas_ids[i])
                else:
                    mc = get_component_by_id(mat_ids[i])
                
                connection_error = False
            except:
                if iter <= max_iter:
                    keep_trying = True
            

        if connection_error:
            raise Exception(Exception_Enum.PHAST_CANT_SOURCE_CUSTOM_CHEMICAL_BY_PHAST_ID)
        mc.mole_fraction = release_molfs[i]
        mat_comps.append(mc)

    material = Material(name = consts.MATERIAL_NAME, components=mat_comps)
    material.component_count = len(chem_names)
    material.property_template = PropertyTemplate.PHAST_MC

    return material

def prep_state(mi = None, press_pa = None, temp_K = None, lf = None, specified_flash_type = None, use_multicomponent_modeling=False) -> State:

    state = State(pressure=None, temperature=None, liquid_fraction=None)
    
    if mi is not None:
        press_pa = mi.PRESS_PA
        temp_K = mi.TEMP_K
        if mi.EXIT_VAPOR_MASS_FRACTION is not None:
            # if press, temp and vf are given, use only vf and press.
            lf = 1 - mi.EXIT_VAPOR_MASS_FRACTION
            if press_pa is not None:
                temp_K = None
        
    
    state.flash_flag = None
    if specified_flash_type is None:
        
        if lf is not None:
            state.liquid_fraction = lf
            if press_pa is not None:
                state.pressure = press_pa
                if temp_K is not None:
                    state.temperature = temp_K
                    state.flash_flag = FluidSpec.PTLF
                else:
                    state.flash_flag = FluidSpec.PLF
            else:
                if temp_K is not None:
                    state.temperature = temp_K
                    state.flash_flag = FluidSpec.TLF
        else:
            if press_pa is not None and temp_K is not None:
                state.pressure = press_pa
                state.temperature = temp_K
                state.flash_flag = FluidSpec.TP

    if specified_flash_type is not None:
        if specified_flash_type == FluidSpec.PBUB:
            p_set = False
            if press_pa is not None:
                state.pressure = press_pa 
                p_set = True
            t_set = False
            if temp_K is not None:
                t_set = True
                state.temperature = temp_K
            if t_set and p_set:
                state.flash_flag = FluidSpec.PBUB

    if state.flash_flag is None:
        raise Exception(Exception_Enum.INVALID_FLASH_INPUTS)
    
    state.mixture_modelling = MixtureModelling.PC
    if use_multicomponent_modeling:
        state.mixture_modelling = MixtureModelling.MC_SINGLE_AEROSOL

    return state


def flash_calc(state:State, material:Material) -> FlashResult:

    flash = FlashCalculation(material=material, material_state=state)
    
    if flash.run() == ResultCode.SUCCESS:
        
        # if state.flashFlag !=FluidSpec.TP and state.flashFlag != FluidSpec.TBUB:
        #     state.flashFlag = FluidSpec.TBUB
        #     state.liquidFraction = 0.0
        #     state.pressure = 0.0
        #     state.temperature = flash.flashResult.bubblePointTemperature

        #     flash = flash_calc(state, material)

        if hasattr(flash, 'messages'):
            if len(flash.messages) > 0:
                print(f'from flash calc: {flash.messages}')

        return flash.flash_result

    # print('Phast Flash Calculation Failed.')

    if hasattr(flash, 'messages'):
        if flash.messages is not None:
            for msg in flash.messages:
                print(msg)
                
    raise Exception(Exception_Enum.PHAST_FLASH_CALC_FAILED)



def prep_vessel(mi, state, material, chems, flashresult, release_duration_sec = 3600, mass_flow_kg_s = -1):

    vessel = Vessel(state=state, material=material)

    vessel.location.x = 0.0
    vessel.location.y = 0.0
    vessel.location.z = 0.0

    vessel_size = Vessel_Sizing(chems = chems, mi= mi, flashresult= flashresult, release_duration_sec= release_duration_sec, mass_flow_kg_s=mass_flow_kg_s)
    vessel_size.get_sizing_and_leak_height()

    vessel.diameter = vessel_size.diam_m
    vessel.height = vessel_size.height_m
    vessel.shape = VesselShape.VERTICAL_CYLINDER
    vessel.liquid_fill_fraction_by_volume = vessel_size.liquid_fill
    vessel.vessel_conditions = vessel_size.vessel_condition
    vessel.location.z = vessel_size.tank_elevation_above_grade_m
    
    return {
        'vessel':  vessel,
        'vessel_size': vessel_size
    }


def prep_leak(mi = None, leak_height_fract_of_vessel = 1, diam_m = -1, leak:Leak = None):

    if leak is None:
        leak = Leak(hole_diameter=diam_m)

        leak.release_angle = 0.0
        leak.time_varying_option = TimeVaryingOption.INITIAL_RATE
        leak.hole_height_fraction = leak_height_fract_of_vessel

    if mi is not None:
        leak.hole_diameter = mi.MAX_HOLE_SZ_M
        leak.release_angle = mi.RELEASE_ANGLE_DEGREES_FROM_HORIZONTAL
    
    if diam_m > 0:
        leak.hole_diameter = diam_m

    return leak

def prep_weather(wx_enum = Wx_Enum.NIGHT):

    weather = Weather()

    weather.stability_class = AtmosphericStabilityClass.STABILITY_F
    weather.wind_speed = Consts.WIND_SPEED_DEFAULT_MS
    weather.wind_profile_flag = WindProfileFlag.POWER_LAW_PROFILE

    weather.temperature = 15 + 273.15
    weather.solar_radiation = 0
    
    if wx_enum != Wx_Enum.NIGHT:
        weather.stability_class = AtmosphericStabilityClass.STABILITY_D
        weather.temperature = 25 + 273.15
        weather.solar_radiation = 500

    return weather

def prep_substrate(mi = None):

    substrate = Substrate()

    substrate.surface_roughness = 0.1
    substrate.surface_type = SurfaceType.LAND
    substrate.pool_surface_type = PoolSurfaceType.CONCRETE

    if mi is not None:
        if mi.AVAILABLE_POOL_AREA_M2 < Consts.POOL_AREA_DEFAULT_M2 and mi.AVAILABLE_POOL_AREA_M2 > 0:
            a = mi.AVAILABLE_POOL_AREA_M2
            v = mi.STORAGE_VOLUME_M3
            h = v / a * 2
            
            d = math.sqrt(4*a/math.pi)
            bund = Bund()

            # artificially make a high bund wall to prevent drift of rainout outside of the containment area.

            h = max(h, mi.RELEASE_ELEVATION_M + 10)
            
            bund.bund_height = h
            bund.bund_diameter = d
            bund.specify_bund = True
            substrate.bund = bund


    return substrate