import copy
import pandas as pd
import numpy as np
import numpy.polynomial.polynomial as poly

from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts
from py_lopa.kml_processing.kml_factory import KML_Factory 
from py_lopa.kml_processing import kml_utils

cd = Consts().CONSEQUENCE_DATA


class Kml_Generator:
    vert_tol_m = 2

    def __init__(self, dispersion_dicts=None, mi = None, save_all_disps_locally = False, save_merged_output_locally = False, output_folder=None, run_info=None, send_to_kml_hander=True, kml_handler=print) -> None:
        self.dispersion_dicts = dispersion_dicts
        self.mi = mi
        self.disp_output_dicts = []
        self.kml_fact = KML_Factory()
        self.save_all_disps_locally = save_all_disps_locally
        self.save_merged_output_locally = save_merged_output_locally
        self.output_folder = output_folder
        self.run_info = run_info
        self.send_to_kml_handler = send_to_kml_hander
        self.kml_handler = kml_handler

    def run(self):
        self.get_elevs_needing_footprints()
        self.get_conc_footprints()
        if len(self.disp_output_dicts) == 0:
            return
        
        self.comb_kml_bytestr = self.kml_fact.get_combined_disp_kml_bytestrs_return_one_str(self.disp_output_dicts)
        kml_utils.prep_kml_data_for_output(kml_bytestr=self.comb_kml_bytestr, merged_kml=True, use_time_stamp=False, debug_mode=self.save_merged_output_locally, kml_gen=self, output_folder=self.output_folder, send_to_kml_handler=self.send_to_kml_handler, kml_handler=self.kml_handler, run_info=self.run_info)

    def get_elevs_needing_footprints(self):
        onsite_elevs_m = copy.deepcopy(Consts.ONSITE_EVAL_CONC_FOOTPRINT_ELEVATIONS)
        if self.mi is not None:
            onsite_elevs_m = self.mi.ONSITE_EVAL_CONC_FOOTPRINT_ELEVATIONS
        
        d_dict_0 = self.dispersion_dicts[0]
        d_0 = d_dict_0[cd.OUTPUT_DISPERSION_OBJECT]
        bldg_elevs_m = d_0.study_bldg_hts
        elevs_not_needed = []
        for b_e in bldg_elevs_m:
            for os_e in onsite_elevs_m:
                if abs(b_e - os_e) <= self.vert_tol_m:
                    elevs_not_needed.append(b_e)
        self.elevs_m = list(set(bldg_elevs_m) - set(elevs_not_needed))
        self.elevs_m.extend(onsite_elevs_m)
        self.elevs_m.sort()
    
    def get_conc_footprints(self):
        self.concUsed = -1
        while len(self.dispersion_dicts) > 0:
            disp_dict = self.dispersion_dicts[0]
            wx = disp_dict[cd.WEATHER_CONDITION]
            haz = disp_dict[cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL]
            dur = disp_dict[cd.OUTPUT_DICT_RELEASE_DURATION_SEC]
            dur_min = max(1, dur / 60)
            disp = disp_dict[cd.OUTPUT_DISPERSION_OBJECT]
            if not disp.has_vapor:
                continue
            disp.max_conc_footprint_for_kml(self.elevs_m)
            kml_bytestr = self.gen_kml_data(haz, wx, dur_min, disp)
            self.dispersion_dicts = self.dispersion_dicts[1:]


            # kml_utils.prep_kml_data_for_output(kml_bytestr=disp.kml_bytestr, haz=haz, dur_min=dur_min, wx= wx, merged_kml=False, use_time_stamp=False, debug_mode=self.save_all_disps_locally, send_to_kml_handler=self.send_to_kml_handler, output_folder=self.output_folder, run_info=self.run_info, kml_handler=self.kml_handler)

            self.disp_output_dicts.append({
                cd.WEATHER_CONDITION: wx,
                cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL: haz,
                cd.OUTPUT_DICT_RELEASE_DURATION_SEC: dur,
                cd.OUTPUT_DISPERSION_KML_BYTESTR: kml_bytestr,
            })

    def gen_kml_data(self, haz, wx_enum, dur_min, disp):
        conc_lat_long_alt_radial_circle_dicts = []
        conc_alt_wd_lon_lat = []
        
        src_lon = disp.mi.RELEASE_LONGITUDE_DEGREE_DECIMAL
        src_lat = disp.mi.RELEASE_LATITUDE_DEGREE_DECIMAL

        df = disp.conc_footprints_df
        grouped = df.groupby(cd.CONC_VOLF_TITLE)
        disp.kml_bytestr = ''
        for c, footprints_ser in grouped:
            zxy, min_max_x_dict = self.get_zxy_and_min_max_x_dict(footprints_ser=footprints_ser)
            if zxy is None:
                continue
            conc_ppm = c * 1e6
            conc_ppm_str = f'{conc_ppm} ppm'
            alt_wd_lon_lat = kml_utils.zxy_src_lon_lat_to_lon_lat_altitude(zxy=zxy, src_lon=src_lon, src_lat=src_lat)
            radial_circle_dict = self.set_radial_circle_dict(src_lon=src_lon, src_lat=src_lat, min_max_x_dict=min_max_x_dict)
            conc_lat_long_alt_radial_circle_dicts.append({
                cd.OUTPUT_CONCENTRATION_USED_PPM_STR: conc_ppm_str,
                cd.RADIAL_CIRCLE_DICT: copy.deepcopy(radial_circle_dict)
            })
            conc_alt_wd_lon_lat.append({
                cd.OUTPUT_CONCENTRATION_USED_PPM_STR: conc_ppm_str,
                cd.ALTITUDE_WD_LON_LAT: copy.deepcopy(alt_wd_lon_lat)
            })

        conc_lat_long_alt_radial_circle_df = pd.DataFrame(conc_lat_long_alt_radial_circle_dicts)
        conc_lat_long_alt_radial_circle_flattened_df = {}

        conc_alt_wd_lon_lat_df = pd.DataFrame(conc_alt_wd_lon_lat)
        conc_alt_wd_lon_lat_flattened_df = {}

        if len(conc_alt_wd_lon_lat_df) > 0 and len(conc_lat_long_alt_radial_circle_df) > 0:
            conc_lat_long_alt_radial_circle_flattened_df = self.flatten_conc_lat_long_alt_radial_circle_df(conc_lat_long_alt_radial_circle_df)
            conc_alt_wd_lon_lat_flattened_df = self.flatten_conc_alt_wd_lon_lat_df(conc_alt_wd_lon_lat_df)

        kml_bytestr = self.kml_fact.gen_kml_bytestr(conc_lat_long_alt_radial_circle_flattened_df, conc_alt_wd_lon_lat_flattened_df, haz, wx_enum, dur_min)

        return kml_bytestr


    def get_zxy_and_min_max_x_dict(self, footprints_ser):
        fp_dict_list = footprints_ser[cd.CONC_CALC_CONC_FOOTPRINT].values[0]
        
        zxy = []
        for fp_dict in fp_dict_list:
            fps = fp_dict[cd.CONC_CALC_CONC_FOOTPRINT]
            cp_s = fps.contour_points
            for cp in cp_s:
                zxy.append([cp.z, cp.x, cp.y])
        
        zxy_np = np.array(zxy)

        if len(zxy_np) == 0:
            return None, None
        
        zxy_np_pos = zxy_np[zxy_np[:,2] > 0]

        zxy_clean, min_max_x_dict = kml_utils.clean_dataset_and_extract_min_max_x(zxy_pos=zxy_np_pos)

        return zxy_clean, min_max_x_dict
    
    def get_poly_fits_dict_for_each_z(self, zxy_conc_used_dict):
        zxy = zxy_conc_used_dict['zxy_pos']
        zxy = zxy[np.lexsort((zxy[:,2], zxy[:,1],zxy[:,0]))]
        zxy_df = pd.DataFrame(zxy, columns=['z', 'x', 'y'])
        grouped = zxy_df.groupby('z')
        polyfits = {}
        for z, xy in grouped:
            x = xy['x']
            y = xy['y']
            coefs = poly.polyfit(x, y, 6)
            polyfits[z] = coefs
        
        return polyfits

    def compute_r2(self, y_true, y_predicted):

        sse = sum((y_true - y_predicted)**2)
        tse = (len(y_true) - 1) * np.var(y_true, ddof=1)
        r2_score = 1 - (sse / tse)
        return r2_score, sse, tse

    def set_radial_circle_dict(self, src_lon, src_lat, min_max_x_dict):

        radial_circle_dict = {}

        for z, min_max_x in min_max_x_dict.items():
            min_x = min_max_x[cd.MIN_X]
            max_x = min_max_x[cd.MAX_X]
            inner_and_outer_radial_bounds_dict = kml_utils.gen_inner_and_outer_radial_circles_long_lat_alt(src_lon=src_lon, src_lat=src_lat, alt=z, outer_rad_m=max_x, inner_rad_m=min_x)
            radial_circle_dict[z] = copy.deepcopy(inner_and_outer_radial_bounds_dict)
        
        return radial_circle_dict
        

    def flatten_conc_lat_long_alt_radial_circle_df(self, conc_lat_long_alt_radial_circle_df):
        
        df = conc_lat_long_alt_radial_circle_df

        flattened = []

        for _, row in df.iterrows():
            conc = row[cd.OUTPUT_CONCENTRATION_USED_PPM_STR]
            radial_circle_dict = row[cd.RADIAL_CIRCLE_DICT]
            for alt in radial_circle_dict.keys():
                flattened.append({
                    cd.OUTPUT_CONCENTRATION_USED_PPM_STR: conc,
                    cd.ALTITUDE: alt,
                    cd.RADIAL_CIRCLE_DICT: radial_circle_dict[alt]
                })

        
        flattened_df = pd.DataFrame(flattened)

        return flattened_df
    
    def flatten_conc_alt_wd_lon_lat_df(self, conc_alt_wd_lon_lat_df):

        df = conc_alt_wd_lon_lat_df
        flattened = []
        for _, row in df.iterrows():
            conc = row[cd.OUTPUT_CONCENTRATION_USED_PPM_STR]
            alt_wd_lon_lat = row[cd.ALTITUDE_WD_LON_LAT]
            for alt in alt_wd_lon_lat.keys():
                wd_lon_lat = alt_wd_lon_lat[alt]
                for wd in wd_lon_lat.keys():
                    flattened.append({
                        cd.OUTPUT_CONCENTRATION_USED_PPM_STR: conc,
                        cd.ALTITUDE: alt,
                        cd.WIND_DIRECTION: wd, 
                        cd.LONG_LAT: wd_lon_lat[wd]
                    })
        
        flattened_df = pd.DataFrame(flattened)

        return flattened_df