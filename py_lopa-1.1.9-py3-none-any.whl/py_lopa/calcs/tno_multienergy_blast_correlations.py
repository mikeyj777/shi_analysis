# this script follows the TNO Multienergy method for determining peak side-on overpressure
# source - https://publications.tno.nl/publication/34634119/QIKv78/TNO-2005-yellow.pdf
# p 505 in pdf, figure 5.8A.

# the plot is log-log, and provides scaled pressure (Psc) vs scaled radius (r') for the multienergy blast strength classes (1-10)
# the lower classes (1-5) have a characteristic shape as follows:
#   flat zone at low r' 
#   followed by concave down curve
#   finally, a log-linear downward line to the x-axis
# the higest class (10) has only a convex downward log-parabola.
# the other classes (6-9) still have the flat zone, concave down curve and a linear section but ultimately converge into the convex downward log-parabola of class 10.

# the lowest plotted Psc value is 0.001.  that is the lowest returned pressure here.

# this method determines which regressed set to use based on the blast strength class and radius, then applies the appropriate regressed constants to return the scaled pressure

import math

def get_psc_given_blast_strength_class_and_scaled_radius(tnoClass, scaled_radius):

    # max r' where Psc is constant
    max_flat = {
        1: 0.50842741,
        2: 0.573902853,
        3: 0.438458551,
        4: 0.50842741,
        5: 0.501629957,
        6: 0.373063398,
        7: 0.404441389,
        8: 0.39105862,
        9: 0.288880545,
        10: 0.24579463,
    }

    # max r' where Psc follows a concave downward curvature (r' larger than max_flat)
    max_concave_downward_curvature = {
        1: 0.692907514,
        2: 0.731235452,
        3: 0.782140363,
        4: 0.931699997,
        5: 0.683643642,
        6: 0.665485804,
        7: 0.551190734,
    }

    # max r' where Psc falls linearly before joining the quadratic.  
    # this only applies to some of the higher classes
    max_downward_linear_range_pre_quadratic = {
        6: 2.565020906,
        7: 0.98843814,
        8: 0.546227722,
        9: 0.380897464,
    }

    max_downward_concave_quadratic = 2.565020906

    r = min(scaled_radius, 100)
    c = tnoClass

    if c < 6:
        psc_function_dict = {
            1: flat if r <= max_flat[c] else concave_downward_curvature if r <= max_concave_downward_curvature[c] else linear_post_quadratic_or_convex_downward,
            2: flat if r <= max_flat[c] else concave_downward_curvature if r <= max_concave_downward_curvature[c] else linear_post_quadratic_or_convex_downward,
            3: flat if r <= max_flat[c] else concave_downward_curvature if r <= max_concave_downward_curvature[c] else linear_post_quadratic_or_convex_downward,
            4: flat if r <= max_flat[c] else concave_downward_curvature if r <= max_concave_downward_curvature[c] else linear_post_quadratic_or_convex_downward,
            5: flat if r <= max_flat[c] else concave_downward_curvature if r <= max_concave_downward_curvature[c] else linear_post_quadratic_or_convex_downward,
        }

    if c == 6 or c == 7:
        psc_function_dict = {
            6: flat if r <= max_flat[c] else concave_downward_curvature if r <= max_concave_downward_curvature[c] else linear_pre_quadratic if r <= max_downward_linear_range_pre_quadratic[c] else quadratic if r <= max_downward_concave_quadratic else linear_post_quadratic_or_convex_downward,
            7: flat if r <= max_flat[c] else concave_downward_curvature if r <= max_concave_downward_curvature[c] else linear_pre_quadratic if r <= max_downward_linear_range_pre_quadratic[c] else quadratic if r <= max_downward_concave_quadratic else linear_post_quadratic_or_convex_downward,
        }
    if c == 8 or c == 9:
        psc_function_dict = {
            8: flat if r <= max_flat[c] else linear_pre_quadratic if r <= max_downward_linear_range_pre_quadratic[c] else quadratic if r <= max_downward_concave_quadratic else linear_post_quadratic_or_convex_downward,
            9: flat if r <= max_flat[c] else linear_pre_quadratic if r <= max_downward_linear_range_pre_quadratic[c] else quadratic if r <= max_downward_concave_quadratic else linear_post_quadratic_or_convex_downward,
        }

    if c == 10:
        psc_function_dict = {10: flat if r <= max_flat[c] else quadratic if r <= max_downward_concave_quadratic else linear_post_quadratic_or_convex_downward}

    psc_function = psc_function_dict[c]

    psc = psc_function(c, r)

    return max(psc, 0.001)

def flat(c, _):

    psc_by_class = {
        1: 0.01,
        2: 0.02,
        3: 0.05,
        4: 0.1,
        5: 0.2,
        6: 0.5,
        7: 1,
        8: 2,
        9: 5,
        10: 16,
    }

    return psc_by_class[c]

def concave_downward_curvature(c, r):

    # while the other zones are regressed using log-linear and log-parabolic, this zone of curvature
    # is going to be a weird shape.  quantifying it as a parabola for simplicity and minimizing introduction of error

    regressed_consts_by_class = {
        1: [-0.02043077,0.020573344,0.00482127], 
        2: [-0.055052319,0.061253279, 0.002978847],
        3: [-0.049898759, 0.033111935, 0.045074621],
        4: [0, -0.066768111, 0.133946738],
        5: [-0.800964121, 0.756470834, 0.022080264],
        6: [-0.614039961, 0.433796864, 0.423626077],
        7: [-5.220146019, 4.191926709, 0.158485434],
    }

    consts = regressed_consts_by_class[c]
    psc = polynomial_regression(consts=consts, x=r)
    return psc


def linear_pre_quadratic(c, r):
    regressed_consts_by_class = {
        6: [0, -1.031773028, -0.538661887],
        7: [0, -1.092329503, -0.336574836],
        8: [0, -0.640175046, 0.04859677],
        9: [0, -0.743204218, 0.324973569],
    }

    consts = regressed_consts_by_class[c]
    log_r = math.log10(r)
    log_psc = polynomial_regression(consts=consts, x=log_r)
    psc = 10**log_psc
    return psc

def quadratic(_, r):
    # the quadratic regime is for the higher classes (6 thru 10) and is consistent for all.
    # it represents the concave downward shape where r' is less than the point where the higher classes converge.
    # at r' greater than this point, the plots converge to a downward log-linear shape.

    consts = [1.028326423, -1.914345937, -0.348096795]
    log_r = math.log10(r)
    log_psc = polynomial_regression(consts=consts, x=log_r)
    psc = 10**log_psc
    return psc

def linear_post_quadratic_or_convex_downward(c, r):
    # linear post quadratic serves both:
    #   the lower classes when r' is greater than the region of convex downward;
    #   and the upper classes where r' is greater than the region of concave downward log-parabola.
    regressed_consts_by_class = {
        1: [0, -0.995763903, -2.191689252],
        2: [0, -1.009002098, -1.873941275],
        3: [0, -0.999171136, -1.499734547],
        4: [0, -1.013651877, -1.175388699],
        5: [0, -0.997214279, -0.94751253],
        6: [0, -1.129629468, -0.498629707],
        7: [0, -1.129629468, -0.498629707],
        8: [0, -1.129629468, -0.498629707],
        9: [0, -1.129629468, -0.498629707],
        10: [0, -1.129629468, -0.498629707],
    }

    consts = regressed_consts_by_class[c]
    log_r = math.log10(r)
    log_psc = polynomial_regression(consts=consts, x=log_r)
    psc = 10**log_psc
    return psc

def polynomial_regression(consts, x):

    # this assumes that quadratic is higest regressed order.
    # consts is an array
    # if linear, ensure consts[0] is zero.

    a = consts[0]
    b = consts[1]
    c = consts[2]

    return a*x**2 + b*x + c