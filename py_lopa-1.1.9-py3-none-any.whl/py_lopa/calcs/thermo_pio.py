from re import X
import sys
import math
import copy
# from chemicals import k
import numpy as np
import pandas as pd
# from scipy.optimize import root
# from thermo import ChemicalConstantsPackage, CEOSGas, CEOSLiquid, PRMIX, FlashVL
# from thermo.interaction_parameters import IPDB

from pypws.calculations import VesselLeakCalculation, FlashCalculation, VesselCatastrophicRuptureCalculation, DischargeRecord
from pypws.entities import State, Material, FlashResult

# from py_lopa.model_work.model_inputs import Model_Inputs
from py_lopa.calcs import helpers
from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.phast_io.phast_discharge import Phast_Discharge
from py_lopa.phast_io import phast_prep
from py_lopa.calcs import dippr_eqns
from py_lopa.classes.solver import Solver
from py_lopa.calcs.consts import Consts
from py_lopa.classes.vessel_sizing import Vessel_Sizing
from py_lopa.phast_io import phast_prep
from py_lopa.data.tables import Tables
from py_lopa.classes.source_input import Source_Input
# from py_lopa.classes.indoor_modeling_3 import Indoor_Modeling_3

consts = Consts()
cd = consts.CONSEQUENCE_DATA
ra = consts.RELEASE_STREAM_ATTRIBS
diff = None

def ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix, mws, overall_molfs, temp_K, press_Pa, cheminfo, liquid_mass_fraction = None):
    # basis:  https://folk.ntnu.no/skoge/bok/mer/flash_english_edition_2009
    # PT Flash - (p. 5)

    chem_mix_names = helpers.get_chem_names(chems_list=chem_mix, cheminfo=cheminfo)

    ks = []
    k_times_zi = []
    zeros_arr = list(np.zeros(len(chem_mix)))
    vpress_components = []
    for i in range(len(chem_mix)):
        
        vp_args = {
           'mixture_cas_nos': [chem_mix[i]],
           'mixture_molfs': [1],
           'cheminfo': cheminfo
        }
        vpress_data = vpress_pa_and_vapor_phase_comp_and_component_vapor_pressures(temp_k= temp_K, args= vp_args)
        vpress_pa = vpress_data['vpress_pa']
        vpress_components.append(vpress_pa)
        # non-condensables will have enormous vapor pressures relative to the system pressure.  
        # capping K at 100 should allow for mixture calcs of non-condensables with higher boilers
        kval = min(vpress_pa / press_Pa, 100) 
        ks.append(kval)
        k_times_zi.append(kval * overall_molfs[i])

    args = {
        'molfs': overall_molfs,
        'ks': ks
    }
    rr_sum_vf_0 = rach_rice_sum(vf = 0, args = args)

    

    rr_sum_vf_1 = rach_rice_sum(vf = 1, args = args)
    
    # if the rach_rice sum is zero at vf = 0, this solves for a liquid system at bubble point.
    # in addition, if the sum is less than zero at both vf = 0 and vf = 1, comp is subcooled.
    if abs(rr_sum_vf_0) < 1e-8 or (rr_sum_vf_0 < 0 and rr_sum_vf_1 < 0):
        vf = 0
        xs = overall_molfs
        ys = zeros_arr
        data =  {
            'chem_mix': chem_mix,
            'chem_mix_names': chem_mix_names,
            'temp_k': temp_K,
            'press_pa': press_Pa,
            'vf': vf,
            'xs': xs,
            'ys': ys,
            'overall_vapor_mass_fraction': 0,
            'vpress_data': vpress_components,
            'ks': ks,
            'overall_molfs': overall_molfs,
            'mws': mws,
            'k_times_zi': k_times_zi,
            'ave_mw_vap': 0,
        }

        

        # spec_enth_j_kg = get_spec_enthalpy_j_kg(data)

        # data['spec_enth_j_kg'] = spec_enth_j_kg
        
        return data
    
    # if the rach_rice sum is zero at vf = 1, this solves for a vapor system at dew point.
    # in addition, if the sum is greater than zero at both vf = 0 and vf = 1, comp is superheated.
    if abs(rr_sum_vf_1) < 1e-8 or (rr_sum_vf_0 > 0 and rr_sum_vf_1 > 0):
        vf = 1
        xs = zeros_arr
        ys = overall_molfs
        ys_np = np.array(ys)
        mws_np = np.array(mws)
        ave_mw_vap = ys_np.dot(mws_np.T)
        data = {
            'chem_mix': chem_mix,
            'chem_mix_names': chem_mix_names,
            'temp_k': temp_K,
            'press_pa': press_Pa,
            'vf': vf,
            'xs': xs,
            'ys': ys,
            'overall_vapor_mass_fraction': 1,
            'vpress_data': vpress_components,
            'ks': ks,
            'overall_molfs': overall_molfs,
            'mws': mws,
            'k_times_zi': k_times_zi,
            'ave_mw_vap': ave_mw_vap,
        }
    
        # spec_enth_j_kg = get_spec_enthalpy_j_kg(data)

        # data['spec_enth_j_kg'] = spec_enth_j_kg
        
        return data

    rr_fail = {
        'chem_mix': chem_mix,
        'chem_mix_names': chem_mix_names,
        'temp_k': temp_K,
        'press_pa': press_Pa,
        'vf': None,
        'xs': zeros_arr,
        'ys': zeros_arr,
        'overall_vapor_mass_fraction': None,
        'vpress_data': vpress_components,
        'ks': ks,
        'overall_molfs': overall_molfs,
        'mws': mws,
        'k_times_zi': k_times_zi,
        'ave_mw_vap': 0
    }

    # if main solver methods fail, it will fall back on bisection method.
    # parameters below needed for bisection
    # ulim = self.bisect_params['upper_limit']
    # llim = self.bisect_params['lower_limit']
    # # if decrease in x is expected to give an increase in y, this is
    # # termed here an "inverse association". 
    # # 'inverse_assoc' would be set to True.
    # inverse_assoc = self.bisect_params['inverse_assoc']
    
    inverse_assoc = (rr_sum_vf_0 > rr_sum_vf_1)
    normal_assoc = not inverse_assoc
    
    vf = 0.5
    solver = Solver(args = args, arg_to_vary=vf, fxn_to_solve=rach_rice_sum, ytol = 0.001)
    solver.set_bisect_parameters(lower_limit=0, upper_limit=1, output_increases_as_input_increases=normal_assoc)
    if not solver.solve():
        return rr_fail

    vf = solver.answer

    # in case one of the non-bisection methods found an unexpected root outside of 0 and 1, 
    # force the solver to run a bisection method
    if vf > 1 or vf < 0:
        if solver.solver_bisect():
            vf = solver.answer
    if vf > 1 or vf < 0:
        return rr_fail
    
    F = 1
    V = vf * F
    L = F - V

    xs = []
    ys = []
    for i in range(len(overall_molfs)):
        xi = overall_molfs[i] / (1 + vf * (ks[i]-1))
        yi = ks[i] * xi
        xs.append(xi)
        ys.append(yi)

    overall_vap_pct = get_overall_vap_mass_pct(xs, ys, vf, mws)

    ys_np = np.array(ys)
    mws_np = np.array(mws)
    ave_mw_vap = ys_np.dot(mws_np.T)

    data = {
        'chem_mix': chem_mix,
        'chem_mix_names': chem_mix_names,
        'temp_k': temp_K,
        'press_pa': press_Pa,
        'vf': vf,
        'xs': xs,
        'ys': ys,
        'overall_vapor_mass_fraction': overall_vap_pct,
        'vpress_data': vpress_components,
        'ks': ks,
        'overall_molfs': overall_molfs,
        'mws': mws,
        'k_times_zi': k_times_zi,
        'ave_mw_vap': ave_mw_vap,
    }

    return data

def rach_rice_sum(vf, args):
    molfs = args['molfs']
    ks = args['ks']
    tot = 0
    for i in range(len(molfs)):
        tot += rach_rice(vf, molfs[i], ks[i])
    return tot

def rach_rice(vf, molf, k):
    # Rachford-Rice equation 
    if (1+vf*(k-1)) == 0:
        pass
    return molf*(k-1)/(1+vf*(k-1))

def get_dew_point_press_pa_return_press_pa_and_flash_data(py_lopa_flash_data, cheminfo, mat = None):
    flash = py_lopa_flash_data
    chem_mix = flash['chem_mix']
    overall_molfs = flash['overall_molfs']
    temp_k = flash['temp_k']
    mws = flash['mws']

    # assumes a sub-cooled mixture
    # dew point press is the pressure at which the sum of y's divided by k's equals one.
    # if pressure is too high, the y's will all be zero.  if too low, the overall sum will be too low
    # this solver starts at atmos pressure and divides by a factor (starts at 10) until the sum is no longer zero.
    # once the sum is not zero, the pressure is bumped back up by the factor
    # factor is then square rooted and starts over
    # once the fator is below a threshold value, the process terminates.

    ans = []
    p_pa = 1013250
    fact = 10
    while p_pa >= 1:
        p_pa /= fact
        flash_res = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=chem_mix, mws=mws, overall_molfs=overall_molfs, temp_K=temp_k, press_Pa=p_pa, cheminfo=cheminfo)
        ks = flash_res['ks']
        ys = flash_res['ys']
        if sum(ys)==0:
            continue
        tot = 0
        for i in range(len(ys)):
            if ks[i] <= 0:
                print('invalid k-factor.  dew point calc may be incorrect')
                continue
            tot += ys[i] / ks[i]
        if fact < 1.01 or abs(1 - tot) < 0.0001:
            break
        if tot != 0:
            p_pa *= fact
            fact = math.sqrt(fact)
    
    p_pa -= 1
    p_pa = max(1,p_pa)

    flash_res = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=chem_mix, mws=mws, overall_molfs=overall_molfs, temp_K=temp_k, press_Pa=p_pa, cheminfo=cheminfo)
    
    ans = {
        'press_pa': p_pa,
        'flash_data': flash_res,
        'pws_material': mat
    }
    
    vf = flash_res['vf']

    if vf < 1:
        ans = get_sys_pressure_pa_and_flash_data_at_vf_1(py_lopa_flash_data, cheminfo, mat)

    return ans
    

def get_dew_point_press_pa_return_press_pa_and_flash_data_with_solver(py_lopa_flash_data, cheminfo, mat = None):
    # run pws flash to get dew point pressure.  reduce pressure by 1 Pa to ensure material in vapor phase.
    # note - this is tuned to subcooled releases.

    flash = py_lopa_flash_data
    chem_mix = flash['chem_mix']
    overall_molfs = flash['overall_molfs']
    temp_k = flash['temp_k']
    press_pa = flash['press_pa']
    mws = flash['mws']

    args = {
        'chem_mix':chem_mix,
        'overall_molfs': overall_molfs,
        'temp_k': temp_k,
        'mws': mws,
        'cheminfo': cheminfo
    }
    
    solver = Solver(arg_to_vary=press_pa, fxn_to_solve=dew_point_flash_for_solver, args = args,target=1)
    solver.set_bisect_parameters(lower_limit=1, upper_limit=101325, output_increases_as_input_increases=True, initial_value=50)

    solve_ok = solver.solve()

    if solve_ok:
        press_pa = solver.answer
        flash = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=chem_mix, temp_K=temp_k, press_Pa=press_pa, overall_molfs = overall_molfs, cheminfo=cheminfo)
        if flash['vf'] == 1:
            ans = {
                'press_pa': press_pa,
                'flash_data': flash,
                'pws_material': None
            }
        else:
            solve_ok = False

    if not solve_ok:
        ans = get_sys_pressure_pa_and_flash_data_at_vf_1(py_lopa_flash_data, cheminfo, mat = mat)
    
    return ans


def dew_point_flash_for_solver(x0, args):

    chem_mix = args['chem_mix']
    overall_molfs = args['overall_molfs']
    temp_k = args['temp_k']
    cheminfo = args['cheminfo']
    mws = args['mws']
    press_pa = x0
    
    flash = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=chem_mix, overall_molfs=overall_molfs, temp_K=temp_k, press_Pa=press_pa, cheminfo=cheminfo, mws=mws)

    ks = flash['ks']
    ys = flash['ys']

    tot = 0
    for i in range(len(ys)):
        if ks[i] <= 0:
            print('invalid k-factor.  dew point calc may be incorrect')
            continue
        tot += ys[i] / ks[i]
    return tot



def get_sys_pressure_pa_and_flash_data_at_vf_1(py_lopa_flash_data, cheminfo, mat:Material = None):

     # run pws flash to get dew point pressure.  reduce pressure by 1 Pa to ensure material in vapor phase.
    
    flash = py_lopa_flash_data
    vf = flash['vf']
    t_k = flash['temp_k']
    xs = flash['xs']
    pool_evap_vpress = flash['vpress_data']
    p_pa = np.inner(xs, pool_evap_vpress)
    molfs = helpers.normalize_fractions(pool_evap_vpress)
    chem_mix = flash['chem_mix']
    mws = helpers.get_mws(chem_mix=chem_mix, cheminfo=cheminfo)
    
    state = phast_prep.prep_state(press_pa=p_pa, temp_K=t_k)
    if mat is None:
        mat = phast_prep.prep_material(cas_ids=chem_mix, release_molfs=molfs, cheminfo=cheminfo)
    pws_flash:FlashResult = phast_prep.flash_calc(state=state, material=mat)

    p_pa_pws = pws_flash.dew_point_pressure - 1
    flash = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=chem_mix, mws = mws, overall_molfs=molfs, temp_K=t_k, press_Pa=p_pa, cheminfo=cheminfo)
    vf = flash['vf']
    while vf < 1:
        p_pa -= 1
        if p_pa <= 0:
            raise Exception(Exception_Enum.INVALID_FLASH_INPUTS)
        flash = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=chem_mix, mws = mws, overall_molfs=molfs, temp_K=t_k, press_Pa=p_pa, cheminfo=cheminfo)
        vf = flash['vf']
    
    return {
        'press_pa': p_pa,
        'flash_data': flash,
        'pws_material': mat
    }
    
    
        

def get_overall_vap_mass_pct(xs, ys, vf, mws):
    vap_moles = np.asarray(ys) * vf
    liq_moles = np.asarray(xs) * (1 - vf)
    mws = np.asarray(mws)
    ave_vap_mass = vap_moles.dot(mws.T)
    ave_liq_mass = liq_moles.dot(mws.T)
    vap_ws = ave_vap_mass / (ave_vap_mass + ave_liq_mass)

    return vap_ws

def liquid_phase_comp_iterate_to_flashresult_at_bubble_point_temp(chems, state, x0 = None):
    # if initial guess for x0 not provided, use btm value in df_release df's molfract series
    df_release = chems.releasing_stream_chem_data

    molfs = df_release[ra.MOLE_FRACT].to_list()
    
    n2_idx = len(molfs) - 1
    if x0 == None:
        cas_nos = df_release[ra.CAS_NO].to_list()
        n2_idx = cas_nos.index(cd.NITROGEN_CAS_NO)
        x0 = molfs[n2_idx] 
    fxn = liquid_comp_solve_iterate_to_flashresult_at_bubble_point_temp
    
    args = {'chems': chems, 'state': state, 'n2_idx': n2_idx}

    # molf_solved = newton(fxn, x0, args=args)

    # print('padding vessel with nitrogen.')
    # print('solver attempt 1')
    # sol = root(fxn, x0, args=(args,))
    # ans = -1

    # determining the required amount of n2 needed in order to bring the system to its bubble point
    # is challenging to do to a reasonable level of accuracy.  normal tolerance levels do not get
    # to the correct solution. in general, a custom secant method implementation with a very tight
    # tolerance can work.
    #
    # "x_tol" is the ratio of successive x approximations in secant method. 
    # a value of 1e-11 takes approx 2 min to solve, and returns a reasonable solution.
    # less tight values will return solutions more quickly, but not suitably accurate.  

    x_tol = 1e-11
    # x_tol = 1e-4

    # print('solving for nitrogen pad amount.  this may take over a minute.')
    solver = Solver(args = args, arg_to_vary= x0, fxn_to_solve=fxn, ytol= 0.001, x_pct_diff_tol = x_tol, use_scipy=True, max_iterations=100)
    solver.set_bisect_parameters(lower_limit=0, upper_limit= 1, output_increases_as_input_increases=False)
 
    ans = -1
    if solver.solve():
        ans = solver.answer

    # molf_solved = newton(fxn, x0, args=args)

    # if molf_solved <= 0:
    #     raise Exception(Exception_Enum.INVALID_FRACT_FOR_VP_COMPOSITION_EVAL)

    if ans <= 0 or ans >= 1:
        raise Exception(Exception_Enum.INVALID_FRACT_FOR_VP_COMPOSITION_EVAL)

    molf_solved = ans


    molfs[n2_idx] = molf_solved
    for i in range(len(molfs)):
        if i == n2_idx:
            continue
        molfs[i] *= (1-molf_solved)
    
    molfs = helpers.normalize_fractions(molfs)

    return molfs

def liquid_comp_solve_iterate_to_flashresult_at_bubble_point_temp(molf_guess, args):
    
    global diff

    chems = args['chems']
    state = args['state']
    n2_idx = args['n2_idx']

    df_release = copy.deepcopy(chems.releasing_stream_chem_data)

    molfs = df_release[ra.MOLE_FRACT].to_list()

    if not isinstance(molf_guess, float):
        molf_guess = float(molf_guess[0])

    molfs[n2_idx] = molf_guess

    for i in range(len(molfs)):
        if i == n2_idx:
            continue
        molfs[i] *= (1-molf_guess)

    molfs = helpers.normalize_fractions(molfs)

    df_release[ra.MOLE_FRACT] = molfs

    chems.releasing_stream_chem_data = df_release

    material = phast_prep.prep_material(chems)

    flashresult = phast_prep.flash_calc(state, material)

    diff = flashresult.bubble_point_temperature - state.temperature

    return diff


def flash_point_deg_K(chems, x0 = 298.15):

    #the overall method for determining ideal mixture flash point:
    #1 - guess a mixture flash point temperature
    #2 - per H.-J. Liaw et al. / Journal of Loss Prevention in the Process Industries 15 (2002) 429–438, eqn 6.
        #calculate the indivual components to the mixture rule:
        #sum(x(i)*gamma(i)*psat(T)(i) / psat(T-flash-point)(i) = 1
    #solve for T

    df = chems.cheminfo
    
    fxn = fp_solve

    args = {
        'chems': chems, 
        'df': df
    }

    solver = Solver(args = args, arg_to_vary=x0, fxn_to_solve=fxn, ytol=0.1)
    solver.set_bisect_parameters(lower_limit=0.1, upper_limit=3000, output_increases_as_input_increases=True)

    # sol = root(fxn, x0, args=args)
    TEMP_K = -300

    if solver.solve():
        TEMP_K = solver.answer
    
    if TEMP_K < 0  or TEMP_K > 3000:
        raise Exception(Exception_Enum.INVALID_TEMP_FOR_NBP_EVAL)


    return TEMP_K

def fp_solve(TEMP_K, args):

    chems = args['chems']
    df = args['df']

    df_release = chems.releasing_stream_chem_data

    contrib = 0

    vp_args = {
        'chems': chems
    }
    
    vp_data = vpress_pa_and_vapor_phase_comp_and_component_vapor_pressures(temp_k = TEMP_K, args=vp_args)
    vpress_pa_each_component = np.asarray(vp_data['component_vapor_pressures_pa'])
    vpress_atm_each_component = vpress_pa_each_component / 101325

    mixture_cas_nos = df_release[ra.CAS_NO].to_list()
    mixture_mws = df_release[ra.MW].to_list()
    mixture_molfs = df_release[ra.MOLE_FRACT].to_list()

    for i in range(len(df_release)):
        c = mixture_cas_nos[i]
        row = df[df['cas_no'] == c]
        lel_atm = row['lel'].values[0] / 1000000
        
        # skip non-flammable contributions to flash point
        if lel_atm < 0 or lel_atm >= 1:
            continue
        molf = mixture_molfs[i]
        vpress_atm_i = vpress_atm_each_component[i]
        
        contrib += molf * vpress_atm_i / lel_atm

    return contrib - 1




def nbp_deg_K(chems = None, x0 = 298.15, mixture_cas_nos = [], mixture_molfs = [], cheminfo = None):

    fxn = vpress_pa_and_vapor_phase_comp_and_component_vapor_pressures

    #vpress for nbp returns pa in gauge.  will equal 0 at nbp.
    args = {
        'chems': chems,
        'mixture_cas_nos': mixture_cas_nos,
        'mixture_molfs': mixture_molfs,
        'cheminfo': cheminfo,
        'find_nbp_K': True,
    }

    llim = 0.1
    ulim = 3000

    if cheminfo is None and chems is not None:
        if hasattr(chems, 'cheminfo'):
            cheminfo = chems.cheminfo

    if cheminfo is not None:
        for cas_no in mixture_cas_nos:
            row = cheminfo[cheminfo['cas_no'] == cas_no]
            t_low_deg_c = helpers.get_data_from_pandas_series_element(row['t_low_deg_c'])
            t_high_deg_c = helpers.get_data_from_pandas_series_element(row['t_high_deg_c'])
            t_low_k = t_low_deg_c + 273.15
            t_high_k = t_high_deg_c + 273.15
            llim = max(llim, t_low_k)
            ulim = min(ulim, t_high_k)


    solver = Solver(args = args, arg_to_vary=x0, fxn_to_solve=fxn, ytol=0.01)
    solver.set_bisect_parameters(lower_limit=llim, upper_limit=ulim, output_increases_as_input_increases=True)

    # sol = root(fxn, x0, args=args)
    TEMP_K = -300

    if solver.solve():
        TEMP_K = solver.answer

    if TEMP_K < 0  or TEMP_K > 3000:
        raise Exception(Exception_Enum.INVALID_TEMP_FOR_NBP_EVAL)

    return TEMP_K

# def vpress_pa_and_vapor_phase_comp_and_component_vapor_pressures(temp_k = -300, chems = None, mi = None, find_nbp_K = False, df_release = None, mixture_cas_nos = [], mixture_molfs = [], cheminfo = None):
def vpress_pa_and_vapor_phase_comp_and_component_vapor_pressures(temp_k = -300, args = {}):

    # this vapor pressure calc can run either with the temperature supplied in TEMP_K or by the 
    # temperature in the model_inputs object, 'mi.TEMP_K'.  

    # if the 'mi' object is supplied, the temp in the mi object will be preferentially used.
    # if the 'mi' object is not supplied, then the user must designate the appropriate temp in 
    # this function's 'TEMP_K' argument
    
    chems = None
    if 'chems' in args:
        chems = args['chems']
    
    mi = None
    if 'mi' in args:
        mi = args['mi']
    
    find_nbp_K = False
    if 'find_nbp_K' in args:
        find_nbp_K = args['find_nbp_K']
    
    df_release = None
    if 'df_release' in args:
        df_release = args['df_release']
    
    mixture_cas_nos = []
    if 'mixture_cas_nos' in args:
        mixture_cas_nos = args['mixture_cas_nos']
    
    mixture_molfs = []
    if 'mixture_molfs' in args:
        mixture_molfs = args['mixture_molfs']
    
    cheminfo = None
    if 'cheminfo' in args:
        cheminfo = args['cheminfo']

    if isinstance(temp_k, np.ndarray):
        temp_k = temp_k[0]

    if mi is not None:
        temp_k = mi.TEMP_K

    if temp_k < 0:
        temp_k = 0.001
        # raise Exception(Exception_Enum.INVALID_TEMP_FOR_NBP_EVAL)
    
    if chems is not None:
        if cheminfo is None:
            cheminfo = chems.cheminfo
        if df_release is None:
            df_release = chems.releasing_stream_chem_data
    
    if df_release is not None:
        mixture_cas_nos = df_release[ra.CAS_NO].to_list()
        mixture_molfs = df_release[ra.MOLE_FRACT].to_list()

    if cheminfo is None:
        raise Exception(Exception_Enum.NBP_CALC_ERROR_CHEM_DB_MISSING)

    df = cheminfo
    tot_vp_pa = 0
    vapor_phase_comp = []
    vpress_pa_comp = []
    

    for i in range(len(mixture_cas_nos)):
        c = mixture_cas_nos[i]
        molf = mixture_molfs[i]
        row = df[df['cas_no'] == c]
        vps = helpers.get_vps(row)
        vp_component = dippr_eqns.eqn_101(vps, temp_k)
        vp_component = max(vp_component, 0)
        vp_current = molf * vp_component
        tot_vp_pa += vp_current
        vpress_pa_comp.append(vp_component)
        vapor_phase_comp.append(vp_current)
    
    if tot_vp_pa > 0:
        for i in range(len(mixture_cas_nos)):
            vapor_phase_comp[i] /= tot_vp_pa

    
    # for use in "nbp_deg_K" function.  if flagged on here, this function will return the 
    # total vapor pressure inside of a list for use with the scipy "root" method.
    if find_nbp_K:
        return tot_vp_pa - 101325
    
    ans = {}

    ans['vpress_pa'] = tot_vp_pa
    ans['vapor_phase_comp_molf'] = vapor_phase_comp
    ans['component_vapor_pressures_pa'] = vpress_pa_comp

    return ans

def get_vapor_phase_comp_and_flash_calc_from_discharge_result(vessel_leak_calc, chems, mi):

    # current Phast interface does not report the vapor phase composition of the released composition.
    # As a temporary fix, utilizing an ideal flash calc.
    # It is not anticipated to have perfect agreement between Phast composition and ideal.

    # This method will be updated to retrieve vapor phase composition of the exit material
    # once provided by Phast. 
    
    exit_components = vessel_leak_calc.exit_material.components
    # check_second_chem_name_to_see_if_only_one_chem_in_table = exit_components[1].name
    # if check_second_chem_name_to_see_if_only_one_chem_in_table == Consts.BLANK_MATERIAL_ENTRY_NAME or \
    #     check_second_chem_name_to_see_if_only_one_chem_in_table == '':
    #     return {
    #         'flash_data': None, 
    #         'vap_molfs': [1], 
    #     }

    cas_nos = []
    mws = []
    zs = []
    for comp in exit_components:
        if comp.name == Consts.BLANK_MATERIAL_ENTRY_NAME or \
            comp.name == '':
            break
        if hasattr(comp, 'cas_id'):
            cas_no = comp.cas_id
        else:
            name = comp.name
            if consts.CUSTOM_CHEM_NAME_APPEND in name:
                name = name[:name.find(consts.CUSTOM_CHEM_NAME_APPEND)]
            cas_no = helpers.get_cas_no(chem = name, cheminfo = chems.cheminfo)
        cas_nos.append(cas_no)
        mws.append(helpers.get_mw(cas_no))
        zs.append(comp.mole_fraction)

    fin_state = vessel_leak_calc.discharge_records[0].final_state

    temp_k = fin_state.temperature
    temp_c = temp_k - 273.15
    vap_molfs = []
    
    p_psig = (fin_state.pressure * 14.6959 / 101325) - 14.6959

    if fin_state.pressure > 101325:        
        mi.LOG_HANDLER(f'Discharge pressure greater than atmospheric.  Discharge pressure is {p_psig} psig.  This could result in lower-than modeled final temperature after expansion.')

    p_Pa = 101325

    data = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=cas_nos, mws=mws, overall_molfs=zs, temp_K= temp_k, press_Pa=p_Pa, cheminfo=chems.cheminfo)

    updated_temp_and_flash_data = match_pylopa_liquid_fract_to_pws_return_adjusted_temperature_deg_k(vlc = vessel_leak_calc, py_lopa_flash_data = data, cheminfo=chems.cheminfo, log_handler=mi.LOG_HANDLER)

    # return {
    #     'temp_k': temp_k,
    #     'py_lopa_flash': py_lopa_flash_data
    # }

    temp_k = updated_temp_and_flash_data['temp_k']
    data = updated_temp_and_flash_data['py_lopa_flash']

    vap_molfs = data['ys']
    if max(vap_molfs) > 0:
        return {
            'flash_data': data,
            'vap_molfs': vap_molfs,
            'discharge_temp_c': temp_c,
            'discharge_press_psig': p_psig,
            'adjusted_temp_c': temp_k - 273.15,
        }

    ys = np.array(data['k_times_zi'])
    if ys.sum() > 0:
        ys /= ys.sum()
        return {
            'flash_data': data,
            'vap_molfs': ys.tolist(),
            'discharge_temp_c': temp_c,
            'discharge_press_psig': p_psig,
            'adjusted_temp_c': temp_k - 273.15,
        }

    # the method below calls Thermo.py in order to both determie the vapor-phase composition
    # and final temperature after expansion (if release is choked).  however, the method appears
    # to utilize a static method, which will not function properly in a web-app environment 
    # with multiple instances (appears the queue treats py-lopa instances as threads).
    # it is commented out.
    # the above ideal flash calc will give the vapor-phase composition, but will not check for
    # cooling due to expansion and any changes to the equilibrium based on that.

    # a call to log handler will show when discharge pressure is greater than atmospheric. 

    # p_Pa = fin_state.pressure
    # constants, properties = ChemicalConstantsPackage.from_IDs(cas_nos)
    # kijs = IPDB.get_ip_asymmetric_matrix('ChemSep PR', constants.CASs, 'kij')
    # eos_kwargs = {'Pcs': constants.Pcs, 'Tcs': constants.Tcs, 'omegas': constants.omegas, 'kijs': kijs}
    # gas = CEOSGas(PRMIX, eos_kwargs=eos_kwargs, HeatCapacityGases=properties.HeatCapacityGases)
    # liquid = CEOSLiquid(PRMIX, eos_kwargs=eos_kwargs, HeatCapacityGases=properties.HeatCapacityGases)
    # flasher = FlashVL(constants, properties, liquid=liquid, gas=gas)
    # pt = flasher.flash(T=temp_k, P=p_Pa, zs=zs)
    # ph = flasher.flash(P=101325, H=pt.H(), zs=zs)

    # if hasattr(ph, 'gas'):
    #     if hasattr(ph.gas, 'zs'):
    #         vap_molfs = ph.gas.zs

    return {
        'flash_data': data,
        'vap_molfs': vap_molfs,
        'discharge_temp_c': temp_c,
        'discharge_press_psig': p_psig,
        'adjusted_temp_c': temp_k - 273.15,
    }

# def match_relief_rate_by_varying_pressure(discharge:Phast_Discharge, mi, relief_rate, rel_duration_sec=3600):

#     # vessel = discharge.vessel
#     # rate_m_s = discharge.vesselLeakCalculation.dischargeRecords[0].finalVelocity

#     # before using a solver routine, check a simple ratio of diameter to sqrt of mass rate
#     # basis:  mass flow is proportional to volume flow by density.
#     # for constant density and pressure, mass flow will be proportional to flow area.
#     # flow area is proportional to the square of diameter

#     orig_press_pa = mi.PRESS_PA

#     p1 = mi.PRESS_PA
#     m1 = discharge.vesselLeakCalculation.dischargeRecords[0].massFlow
#     m2 = relief_rate
#     p2 = p1 * (m2 / m1) ** 2

#     vessel = discharge.vessel

#     mi.MAX_HOLE_SZ_M = d2
#     if abs(m1 - m2) / m2 > Consts.TOLERABLE_RELIEF_RATE_DEVIATION_FROM_VESSEL_CALCS:
#         vessel_info = phast_prep.prep_vessel(
#             mi = mi,
#             state = discharge.state,
#             material=discharge.material,
#             chems=discharge.chems,
#             flashresult=discharge.flashresult,
#             release_duration_sec=rel_duration_sec,
#             mass_flow_kg_s=relief_rate
#         )
#         vessel = vessel_info['vessel']

#     leak = discharge.leak
#     leak = phast_prep.prep_leak(diam_m = d2, leak=leak)

#     discharge = Phast_Discharge(
#         leak=leak, 
#         state=discharge.state, 
#         material=discharge.material, 
#         vessel=vessel, 
#         chems=discharge.chems, 
#         mi=mi, 
#         flashresult=discharge.flashresult
#     )

#     discharge.run()
    
#     mass_flow_kg_s = discharge.vesselLeakCalculation.dischargeRecords[0].massFlow

#     if abs(mass_flow_kg_s - relief_rate) / relief_rate <= Consts.TOLERABLE_RELIEF_RATE_DEVIATION_FROM_VESSEL_CALCS:
#         new_diam = d2

#         if abs(new_diam - orig_diam)/orig_diam > Consts.TOLERANCE_RATIO_SOLVED_DIAM_VS_USER_ENTERED_DIAM:
#             orig_diam_str = '{:.4}'.format(orig_diam * 3.28084 * 12)
#             new_diam_str = '{:.4}'.format(new_diam * 3.28084 * 12)
#             mi.LOG_HANDLER(f'To converge on user-supplied relief rate, the model updated the leak diameter significantly.  User-Supplied Diameter: {orig_diam_str} in.  Model Calculated Diameter:  {new_diam_str} in.')

#         return discharge

#     leak_height = discharge.leak.holeHeightFraction

#     args = {'discharge': discharge, 'mi': mi, 'rel_rate_targ': relief_rate, 'rel_duration_sec': rel_duration_sec}
#     arg_to_vary = discharge.leak.holeDiameter
#     fxn_to_solve = solve_for_relief_rate
#     ytol = 0.01
#     target = relief_rate

#     solver = Solver(args=args, arg_to_vary=arg_to_vary, fxn_to_solve=fxn_to_solve, ytol=ytol, x_pct_diff_tol = 0.0001, max_iterations = 60, target = target )
    
#     solver.set_bisect_parameters(lower_limit = 0, upper_limit = 10000, output_increases_as_input_increases = True)

#     if not solver.solve():
#         raise Exception(Exception_Enum.CONVERGENCE_ERROR_RELIEF_RATE_USER_SUPPLIED)

#     new_diam = solver.answer

#     if abs(new_diam - orig_diam)/orig_diam > Consts.TOLERANCE_RATIO_SOLVED_DIAM_VS_USER_ENTERED_DIAM:
#         orig_diam_str = '{:.4}'.format(orig_diam * 3.28084 * 12)
#         new_diam_str = '{:.4}'.format(new_diam * 3.28084 * 12)
#         mi.LOG_HANDLER(f'To converge on user-supplied relief rate, the model updated the leak diameter significantly.  User-Supplied Diameter: {orig_diam_str} in.  Model Calculated Diameter:  {new_diam_str} in.')

#     leak = phast_prep.prep_leak(mi = mi, leak_height_fract_of_vessel = leak_height, diam_m = new_diam)
#     state = discharge.state
#     material = discharge.material
#     vessel = discharge.vessel
#     chems = discharge.chems
#     flashresult = discharge.flashresult
    
#     discharge = Phast_Discharge(leak=leak, state = state, material = material, vessel = vessel, chems = chems, mi = mi, flashresult=flashresult)
#     discharge.run()

#     return discharge

def match_relief_rate(discharge:Phast_Discharge, mi, relief_rate, rel_duration_sec=3600):

    # vessel = discharge.vessel
    # rate_m_s = discharge.vesselLeakCalculation.dischargeRecords[0].finalVelocity

    # before using a solver routine, check a simple ratio of diameter to sqrt of mass rate
    # basis:  mass flow is proportional to volume flow by density.
    # for constant density and pressure, mass flow will be proportional to flow area.
    # flow area is proportional to the square of diameter

    orig_diam = discharge.leak.hole_diameter

    d1 = discharge.leak.hole_diameter
    m1 = discharge.vesselLeakCalculation.discharge_records[0].mass_flow
    m2 = relief_rate
    d2 = d1 * math.sqrt(m2 / m1)

    vessel = discharge.vessel

    mi.MAX_HOLE_SZ_M = d2
    if abs(m1 - m2) / m2 > Consts.TOLERABLE_RELIEF_RATE_DEVIATION_FROM_VESSEL_CALCS:
        vessel_info = phast_prep.prep_vessel(
            mi = mi,
            state = discharge.state,
            material=discharge.material,
            chems=discharge.chems,
            flashresult=discharge.flashresult,
            release_duration_sec=rel_duration_sec,
            mass_flow_kg_s=relief_rate
        )
        vessel = vessel_info['vessel']

    leak = discharge.leak
    leak = phast_prep.prep_leak(diam_m = d2, leak=leak)

    discharge = Phast_Discharge(
        leak=leak, 
        state=discharge.state, 
        material=discharge.material, 
        vessel=vessel, 
        chems=discharge.chems, 
        mi=mi, 
        flashresult=discharge.flashresult
    )

    discharge.run()
    
    mass_flow_kg_s = discharge.vesselLeakCalculation.discharge_records[0].mass_flow

    if abs(mass_flow_kg_s - relief_rate) / relief_rate <= Consts.TOLERABLE_RELIEF_RATE_DEVIATION_FROM_VESSEL_CALCS:
        new_diam = d2

        if abs(new_diam - orig_diam)/orig_diam > Consts.TOLERANCE_RATIO_SOLVED_DIAM_VS_USER_ENTERED_DIAM:
            orig_diam_str = '{:.4}'.format(orig_diam * 3.28084 * 12)
            new_diam_str = '{:.4}'.format(new_diam * 3.28084 * 12)
            mi.LOG_HANDLER(f'To converge on user-supplied relief rate, the model updated the leak diameter significantly.  User-Supplied Diameter: {orig_diam_str} in.  Model Calculated Diameter:  {new_diam_str} in.')

        return discharge

    leak_height = discharge.leak.hole_height_fraction

    args = {'discharge': discharge, 'mi': mi, 'rel_rate_targ': relief_rate, 'rel_duration_sec': rel_duration_sec}
    arg_to_vary = discharge.leak.hole_diameter
    fxn_to_solve = solve_for_relief_rate
    ytol = 0.01
    target = relief_rate

    solver = Solver(args=args, arg_to_vary=arg_to_vary, fxn_to_solve=fxn_to_solve, ytol=ytol, x_pct_diff_tol = 0.0001, max_iterations = 60, target = target )
    
    solver.set_bisect_parameters(lower_limit = 0, upper_limit = 10000, output_increases_as_input_increases = True)

    if not solver.solve():
        raise Exception(Exception_Enum.CONVERGENCE_ERROR_RELIEF_RATE_USER_SUPPLIED)

    new_diam = solver.answer

    if abs(new_diam - orig_diam)/orig_diam > Consts.TOLERANCE_RATIO_SOLVED_DIAM_VS_USER_ENTERED_DIAM:
        orig_diam_str = '{:.4}'.format(orig_diam * 3.28084 * 12)
        new_diam_str = '{:.4}'.format(new_diam * 3.28084 * 12)
        mi.LOG_HANDLER(f'To converge on user-supplied relief rate, the model updated the leak diameter significantly.  User-Supplied Diameter: {orig_diam_str} in.  Model Calculated Diameter:  {new_diam_str} in.')

    leak = phast_prep.prep_leak(mi = mi, leak_height_fract_of_vessel = leak_height, diam_m = new_diam)
    state = discharge.state
    material = discharge.material
    vessel = discharge.vessel
    chems = discharge.chems
    flashresult = discharge.flashresult
    
    discharge = Phast_Discharge(leak=leak, state = state, material = material, vessel = vessel, chems = chems, mi = mi, flashresult=flashresult)
    discharge.run()

    return discharge

def solve_for_relief_rate(x0, args):

    discharge = args['discharge']
    mi = args['mi']
    rel_duration_sec = args['rel_duration_sec']
    rel_rate = args['rel_rate_targ']
    leak = discharge.leak
    diam_m = x0
    leak = phast_prep.prep_leak(diam_m=diam_m, leak = leak)
    state = discharge.state
    material = discharge.material
    chems = discharge.chems
    flashresult = discharge.flashresult
    vessel = discharge.vessel

    if leak.hole_diameter > vessel.diameter * Consts.MAX_HOLE_SIZE_IN_PCT_OF_VESSEL_DIAM:
        vessel_info = phast_prep.prep_vessel(
            mi = mi,
            state = discharge.state,
            material=discharge.material,
            chems=discharge.chems,
            flashresult=discharge.flashresult,
            release_duration_sec=rel_duration_sec,
            mass_flow_kg_s=rel_rate
        )
        vessel = vessel_info['vessel']
    

    discharge = Phast_Discharge(leak=leak, state = state, material = material, vessel = vessel, chems = chems, mi = mi, flashresult=flashresult)
    discharge.run()
    
    if not discharge.dischargeCalcOK:
        return -1
    
    mass_rate_kg_s = discharge.vesselLeakCalculation.discharge_records[0].mass_flow

    return mass_rate_kg_s

def match_vol_release_in_specified_duration(discharge:Phast_Discharge, vol_released_m3, duration_s, vessel_sizing):

    mi = discharge.mi
    state = discharge.state
    material = discharge.material
    vessel = discharge.vessel
    chems = discharge.chems
    leak = discharge.leak
    vds = vessel_sizing.vds
    
    lin_veloc_m_s = discharge.vesselLeakCalculation.discharge_records[0].orifice_velocity
    vol_rate_m3_s = vol_released_m3 / duration_s
    area_m2 = vol_rate_m3_s / lin_veloc_m_s
    if area_m2 <= 0:
        raise Exception(Exception_Enum.INVALID_LEAK_RATE)
    hole_sz_m = math.sqrt(4*area_m2 / math.pi)
    
    if hole_sz_m > vessel.diameter * Consts.MAX_HOLE_SIZE_IN_PCT_OF_VESSEL_DIAM:
        vess_size = Vessel_Sizing()
        vess_size.mi = mi
        vess_size.set_diam_ht_elev_above_ground_meters(vol_released_m3=vol_released_m3, vessel_dimension_specifications=vds, hole_sz_m=hole_sz_m)
        
        vessel.diameter = vess_size.diam_m
        vessel.height = vess_size.height_m
        vessel.location.z = vess_size.tank_elevation_above_grade_m

    leak = phast_prep.prep_leak(diam_m = hole_sz_m, leak = leak)

    discharge = Phast_Discharge(leak=leak, state = state, material = material, vessel = vessel, chems = chems, mi = mi)
    discharge.run()

    return discharge

def mix_temp_deg_k(mix_a_cas_nos, mix_a_molfs, temp_k_a, mix_b_cas_nos, mix_b_molfs, temp_k_b, enthalpy_in, use_bisect_solver_only = False):

    ht_cap_data = helpers.get_dataframe_from_csv(Tables().HEAT_CAPACITY_DATA)

    if len(mix_a_cas_nos) != len(mix_a_molfs):
        return -np.inf
    
    if len(mix_b_cas_nos) != len(mix_b_molfs):
        return -np.inf
    
    ht_caps = {}

    for mixture in [mix_a_cas_nos, mix_b_cas_nos]:

        for i in range(len(mixture)):
            cas = mixture[i]
            if cas in ht_caps.keys():
                continue
            t_min_k = helpers.vlookup_value_x_in_pandas_dataframe_df_in_col_y_get_data_in_column_z(x = cas, df = ht_cap_data, y = 'cas_no', z = 't_min')
            t_max_k = helpers.vlookup_value_x_in_pandas_dataframe_df_in_col_y_get_data_in_column_z(x = cas, df = ht_cap_data, y = 'cas_no', z = 't_max')
            
            # if heat capacity consts are out of range, just use ambient temperature in the dispersion model
            if t_min_k > min(temp_k_a, temp_k_b):
                return 298.15
            if t_max_k < max(temp_k_a, temp_k_b):
                return 298.15
            ht_cap_list = []

            eqn_id = helpers.vlookup_value_x_in_pandas_dataframe_df_in_col_y_get_data_in_column_z(x = cas, df = ht_cap_data, y = 'cas_no', z = 'eqn_id')
            eqn_id = str(eqn_id)

            for c in range(97,104):
                targ_col = 'icp_' + chr(c)
                cp_const = helpers.vlookup_value_x_in_pandas_dataframe_df_in_col_y_get_data_in_column_z(x = cas, df = ht_cap_data, y = 'cas_no', z = targ_col)
                ht_cap_list.append(cp_const)
            chem_ht_cap_data = {
                'eqn_id': eqn_id,
                'cp_consts': copy.deepcopy(ht_cap_list)
            }
            ht_caps[cas] = copy.deepcopy(chem_ht_cap_data)

    args = {
        'heat_capacity_by_cas': ht_caps,
        'mix_a_cas_nos': mix_a_cas_nos,
        'mix_b_cas_nos': mix_b_cas_nos,
        'mix_a_molfs': mix_a_molfs,
        'mix_b_molfs': mix_b_molfs,
        'temp_k_a': temp_k_a,
        'temp_k_b': temp_k_b,
    }

    arg_to_vary = (temp_k_b + temp_k_a) / 2

    solver = Solver(args=args, arg_to_vary=arg_to_vary, fxn_to_solve=energy_balance_for_solver, target=enthalpy_in, ytol=10)
    solver.set_bisect_parameters(lower_limit=min(temp_k_a, temp_k_b), upper_limit=max(temp_k_a, temp_k_b))
    if use_bisect_solver_only:
        solved = solver.solver_bisect()
    else:
        solved = solver.solve()
    if solved:
        return solver.answer

    return -np.inf

def energy_balance_for_solver(t, args):
    
    heat_capacity_by_cas = args['heat_capacity_by_cas']
    mix_a_cas_nos = args['mix_a_cas_nos']
    mix_b_cas_nos = args['mix_b_cas_nos']
    mix_a_molfs = args['mix_a_molfs']
    mix_b_molfs = args['mix_b_molfs']
    temp_k_a = args['temp_k_a']
    temp_k_b = args['temp_k_b']

    mixture_cas_nos = [mix_a_cas_nos, mix_b_cas_nos]
    temps = [temp_k_a, temp_k_b]
    mixture_molfs = [mix_a_molfs, mix_b_molfs]

    tot_h = 0

    for cas_nos, temp_k, molfs in zip(mixture_cas_nos, temps, mixture_molfs):
        for i in range(len(cas_nos)):
            ht_cap_data = heat_capacity_by_cas[cas_nos[i]]
            eqn_id = ht_cap_data['eqn_id']
            consts = ht_cap_data['cp_consts']
            method_to_call = getattr(dippr_eqns, 'eqn_' + eqn_id)
            # def eqn_100(consts, t, integrated = False):

            integ_cp_dt_chem = method_to_call(consts = consts, t = temp_k, integrated = True)
            integ_cp_dt_t_guess = method_to_call(consts = consts, t = t, integrated = True)

            tot_h += molfs[i] * (integ_cp_dt_t_guess - integ_cp_dt_chem)
    
    return tot_h

def match_pylopa_liquid_fract_to_pws_return_adjusted_temperature_deg_k(vlc, py_lopa_flash_data, cheminfo, log_handler):

    dr_0:DischargeRecord = vlc.discharge_records[0]

    pws_liquid_mass_fraction = dr_0.final_state.liquid_fraction

    chem_mix_and_molf = helpers.get_cas_nos_and_mol_fracts_from_material(vlc.exit_material,cheminfo)
    chem_mix = chem_mix_and_molf['cas_nos']
    
    fin_state = dr_0.final_state
    temp_k = fin_state.temperature

    if len(set(chem_mix)) > 1:
        ans = check_for_diff_bet_pws_and_py_lopa_flash_return_adjusted_temperature_deg_k_and_py_lopa_flash(vlc, py_lopa_flash_data, pws_liquid_mass_fraction, cheminfo, temp_k, log_handler)
        temp_k = ans['adjusted_temp_k']
        py_lopa_flash_data = ans['py_lopa_flash']
    else:
        adjust_for_pure_component(py_lopa_flash_data, pws_liquid_mass_fraction, chem_mix)

    return {
        'temp_k': temp_k,
        'py_lopa_flash': py_lopa_flash_data
    }
    
    

def adjust_for_pure_component(py_lopa_flash_data, pws_liquid_mass_fraction, chem_mix):

    # the py_lopa flash calculation should match the amount of vapor/liquid fraction predicted from the discharge calculation.
    # if it is a pure component releasing, it is impossible for the flash calc to determine the fraction vapor vs liquid.
    # in this event, the flash data is manually updated to reflect the values from the discharge calculation.

    # cleuging around a restriction that single-component vessel leak calcs with more than one phase have to have flashes that are either t_bub or p_bub, and both of those 
    # flash types are crashing.

    # for these situations, the chemical is repeated.  here, that repeating chemical will be represented in its appropriate phase.

    py_lopa_liq_mass_fraction = 1 - py_lopa_flash_data['overall_vapor_mass_fraction']

    if pws_liquid_mass_fraction != py_lopa_liq_mass_fraction:

        # pure component. vf (molar) will have same value as mass-based vapor fraction value
        disch_vfm = 1 - py_lopa_liq_mass_fraction
        py_lopa_flash_data['vf'] = disch_vfm
        py_lopa_flash_data['overall_vapor_mass_fraction'] = disch_vfm

        py_lopa_flash_data['xs'] = [0] * len(chem_mix)
        py_lopa_flash_data['ys'] = [0] * len(chem_mix)
        if pws_liquid_mass_fraction > 0:
            py_lopa_flash_data['xs'] = [1]  * len(chem_mix)
        
        if pws_liquid_mass_fraction < 1:
            py_lopa_flash_data['ys'] = [1] * len(chem_mix)


def check_for_diff_bet_pws_and_py_lopa_flash_return_adjusted_temperature_deg_k_and_py_lopa_flash(vlc, py_lopa_flash_data, pws_liquid_mass_fraction, cheminfo, temp_k, log_handler):

    ideal_flash_overall_liq_mass_fract = 1 - py_lopa_flash_data['overall_vapor_mass_fraction']

    mass_fract_tol_pct = 0.05
    pws_liquid_mass_fract_for_comparison = pws_liquid_mass_fraction
    new_temp_k = temp_k
    if pws_liquid_mass_fraction == 0:
        pws_liquid_mass_fract_for_comparison = 1e-16
    if ideal_flash_overall_liq_mass_fract == 0:
        ideal_flash_overall_liq_mass_fract = 1e-16
    
    if abs(ideal_flash_overall_liq_mass_fract - pws_liquid_mass_fract_for_comparison)/ pws_liquid_mass_fract_for_comparison > mass_fract_tol_pct:
        ans = match_liquid_mass_fraction_in_ideal_flash_calc_vary_temp(vlc, py_lopa_flash_data, pws_liquid_mass_fraction, cheminfo)
        # add output for original pws vf, ideal vf
        new_temp_k = ans['temp_k']
        new_discharge_flash_data = ans['flash_data']
        new_lf = 1 - new_discharge_flash_data['overall_vapor_mass_fraction']
        
        log_handler(f'\n\nDischarge liquid fraction calculated by PWS was different than the ideal calculation\nTemperature for flash calculation updated to match vapor fractions.  \nOriginal temperature {temp_k} K.\nNew estimated temperature {new_temp_k} K.\nPWS liquid mass fraction: {pws_liquid_mass_fraction}.\nOriginal Ideal Liquid Mass Fraction: {ideal_flash_overall_liq_mass_fract}.\nNew Estimated Ideal Liquid Mass Fraction: {new_lf}\n\n')
        
        if abs(new_temp_k - temp_k) / temp_k > 0.05:
            log_handler("This significant temperature deviation may result in model inaccuracy.  Terminating Model.")
            raise Exception(Exception_Enum.LARGE_TEMPERATURE_DIFFERENCE_REQUIRED_TO_MATCH_PWS_LIQUID_FRACTION)

        py_lopa_flash_data = new_discharge_flash_data


    return {
        'adjusted_temp_k': new_temp_k,
        'py_lopa_flash': py_lopa_flash_data
    }

def match_liquid_mass_fraction_in_ideal_flash_calc_vary_temp(vlc, py_lopa_flash_data, pws_liquid_mass_fraction, cheminfo):


    chem_mix_and_molf = helpers.get_cas_nos_and_mol_fracts_from_material(vlc.exit_material,cheminfo)

    cas_nos = chem_mix_and_molf['cas_nos']
    molfs = chem_mix_and_molf['molfs']
    mws = helpers.get_mws(cas_nos, cheminfo)
    
    dr_0:DischargeRecord = vlc.discharge_records[0]

    fin_state = dr_0.final_state
    press_pa = fin_state.pressure
    temp_k = fin_state.temperature
    
    lf_ideal = 1 - py_lopa_flash_data['overall_vapor_mass_fraction']
    lf_pws = pws_liquid_mass_fraction # target value

    lf_tol_pct = 0.05

    # use a simple bisection method with tight range.  
    # secant may overshoot potentially small window.
    temp_k_high = temp_k
    temp_k_low = temp_k

    ready_for_solver = False
    if lf_ideal < lf_pws:

        while lf_ideal < lf_pws:
            temp_k_low -= 0.01
            flash_data = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=cas_nos, mws=mws, overall_molfs=molfs, temp_K=temp_k_low, press_Pa=press_pa, cheminfo=cheminfo)
            lf_ideal = 1 - flash_data['overall_vapor_mass_fraction']
        
        if lf_pws == 0:
            lf_pws = 1e-16
            if lf_ideal == 0:
                lf_ideal = 1e-16

        if abs(lf_ideal - lf_pws) / lf_pws < lf_tol_pct:
            return {
                'temp_k': temp_k_low,
                'flash_data': flash_data
            }
        

        ready_for_solver = True
    
    if not ready_for_solver and lf_ideal > lf_pws:

        while lf_ideal > lf_pws:
            temp_k_high += 0.01
            flash_data = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=cas_nos, mws=mws, overall_molfs=molfs, temp_K=temp_k_high, press_Pa=press_pa, cheminfo=cheminfo)
            lf_ideal = 1 - flash_data['overall_vapor_mass_fraction']

        if lf_pws == 0:
            lf_pws = 1e-16
            if lf_ideal == 0:
                lf_ideal = 1e-16

        if abs(lf_ideal - lf_pws) / lf_pws < lf_tol_pct:
            return {
                'temp_k': temp_k_high,
                'flash_data': flash_data
            }
    
    args = {
        'chem_mix': cas_nos,
        'mws': mws,
        'overall_molfs': molfs,
        'press_Pa': press_pa,
        'cheminfo': cheminfo,
        'source_obj': vlc
    }
    
    arg_to_vary = (temp_k_high + temp_k_low) / 2

    solver = Solver(args=args, arg_to_vary=arg_to_vary, fxn_to_solve=get_liquid_fraction_at_temp_for_solver, ytol=0.001, max_iterations=600, target=lf_pws)
    solver.set_bisect_parameters(lower_limit=temp_k_low, upper_limit=temp_k_high, output_increases_as_input_increases=False)

    if not solver.solver_bisect():
        raise Exception(Exception_Enum.UNKNOWN_ERROR_IN_INDOOR_MODELING)
    
    flash_data = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=cas_nos, mws=mws, overall_molfs=molfs, temp_K=solver.answer, press_Pa=press_pa, cheminfo=cheminfo)

    return {
        'temp_k': solver.answer,
        'flash_data': flash_data
    }

def get_liquid_fraction_at_temp_for_solver(x0, args):

    chem_mix = args['chem_mix']
    mws = args['mws']
    overall_molfs = args['overall_molfs']
    press_pa = args['press_Pa']
    cheminfo = args['cheminfo']
    
    temp_k = x0
    flash_data = ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=chem_mix, mws=mws, overall_molfs=overall_molfs, temp_K=temp_k, press_Pa=press_pa, cheminfo=cheminfo)
    lf_ideal = 1 - flash_data['overall_vapor_mass_fraction']

    return lf_ideal


# everything below must be updated to solve for system at specified temp, press and vap quality

def check_for_diff_bet_target_liquid_mass_fraction_at_rate_and_pws_liquid_mass_fraction_return_adjusted_temperature_deg_k_press_pa_and_diameter_m(pd:Phast_Discharge, target_liquid_mass_fraction = None):

    vlc = pd.vesselLeakCalculation
    mi = pd.mi
    
    if target_liquid_mass_fraction is None:
        target_liquid_mass_fraction = 1 - mi.EXIT_VAPOR_MASS_FRACTION
    
    pws_liquid_mass_fraction = vlc.discharge_records[0].final_state.liquid_fraction
    
    temp_k = mi.TEMP_K
    press_pa = mi.PRESS_PA
    diam_m = mi.MAX_HOLE_SZ_M
    ans = {
        'temp_k': temp_k,
        'press_pa': press_pa,
    }

    tol = 0.1
    if abs(pws_liquid_mass_fraction - target_liquid_mass_fraction) / target_liquid_mass_fraction < tol:
        return ans
    arg_to_vary = [temp_k, press_pa]
    targ = target_liquid_mass_fraction
    args = {
        'target': targ, 
        'pd':pd
    }
    fxn_to_solve = get_pws_liquid_fraction_at_temp_for_solver

    solver = Solver(arg_to_vary=arg_to_vary, fxn_to_solve=fxn_to_solve,args=args, target = targ, use_scipy_minimize_only = True)
    targ_keys = list(ans.keys())
    bounds = [[v * (1-tol), v * (1+tol)] for v in arg_to_vary]
    solver.set_scipy_minimize_output_keys_and_bounds(targ_keys=targ_keys, bounds=bounds)
    sol_ok = solver.solve()

    if not sol_ok:
        return {}

    ans = solver.answer

    if not mi.RELIEF_CALC_AVAILABLE:
        return ans
    
    # if the "relief calc available" flag was set, this indicates that the user
    # provided discharge temp and pressure values.  in this case, check if the pws modeled
    # discharge t and p values are not wildly different than the specified values.

    props_in_spec = {}
    for i in range(len(arg_to_vary)):
        prop = targ_keys[i]
        val = ans[prop]
        x0 = arg_to_vary[i]
        if x0 == 0:
            x0 = 1e-16

        props_in_spec[prop] = abs(x0 - val) / x0 <= tol
            
    in_spec = all(props_in_spec.values())

    if not in_spec:
        # implement refinement strategy here.  run scipy minimize again with bounds
        return {}

    return ans


def get_pws_liquid_fraction_at_temp_for_solver(x0, args = None):

    temp_k, press_pa = x0

    target = args['target']
    pd:Phast_Discharge = args['pd']
    material = pd.material

    state:State = phast_prep.prep_state(press_pa=press_pa, temp_K=temp_k)
    flash_result:FlashResult = phast_prep.flash_calc(state=state, material=material)

    pd.flashresult = flash_result
    pd.prep_vessel_leak_calc()
    pd.run()

    lmf = pd.vesselLeakCalculation.discharge_records[0].final_state.liquid_fraction
    
    diff_sq = (lmf - target) ** 2 

    print(f'\n\n---------------------\ndiff sq: {diff_sq}.  curr lmf: {lmf}.  targ lmf: {target}\n\n\n')

    return diff_sq


# from py_lopa.model_work.model_inputs import Model_Inputs