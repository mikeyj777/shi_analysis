import os
import csv
import sys
import copy

import numpy as np
import pandas as pd

import datetime
from datetime import datetime as dt

from pypws.entities import State, Leak, Material, MaterialComponent, Vessel, MixtureModelling, ResultCode, FlashResult, Phase, VesselConditions, VesselShape, DischargeParameters, FlashAtOrifice, Weather, Substrate, AtmosphericStabilityClass, DispersionParameters, DispersionOutputConfig, SpecialConcentration, DischargeRecord
from pypws.calculations import FlashCalculation, VesselStateCalculation, VesselLeakCalculation, DispersionCalculation, MaxConcDistanceCalculation
from pypws.enums import Resolution, FluidSpec, ResultCode
from pypws.materials import *

from py_lopa.calcs import helpers, thermo_pio
from py_lopa.calcs.get_phys_props import Get_Phys_Props
from py_lopa.calcs.consts import Consts
from py_lopa.data.tables import Tables
from py_lopa.data.exception_enum import Exception_Enum

# from calcs.get_phys_props import Get_Phys_Props
# from phast_io import phast_discharge

# chems_to_check = helpers.get_dataframe_from_csv('chems_to_check.csv')
# chem_phys_props = helpers.get_dataframe_from_csv('all_tg_chems.csv')

class Discharge_Calculator:

    def __init__(self, chem_mix=['hydrogen'], molar_basis = True, chem_composition = [1], temp_C = 25, press_psig = 50, diam_in = 4, log_handler=print, include_pws_flash_data=False, prep_objects_but_dont_calculate_discharge=False):
        self.t0 = dt.now(datetime.UTC)
        self.error_msg = ''
        self.model_ok = True
        press_psia = press_psig + 14.6959
        self.press_pa = press_psia * 101325 / 14.6959
        self.temp_k = temp_C + 273.15
        self.chem_mix = chem_mix
        self.composition = chem_composition
        self.comp_is_moles = molar_basis
        self.diam_m = diam_in / 12 / 3.28084
        self.log_handler = log_handler
        self.include_pws_flash_data = include_pws_flash_data
        self.prep_objects_but_dont_calculate_discharge = prep_objects_but_dont_calculate_discharge
        self.material = None
        self.discharge_result = {}

    def run(self) -> ResultCode:
        if self.material is None:
            self.get_cheminfo()
            self.get_cas_nos()
            self.get_molar_comp()
            self.set_material()
            self.set_state()
        
            self.flash_wrapper()
            if not self.model_ok:
                return ResultCode.FAIL_EXECUTION
        self.set_leak()
        self.set_vessel()
        
        if not self.prep_objects_but_dont_calculate_discharge:
            self.disch_wrapper()
            if self.model_ok:
                self.get_discharge_results()
                return ResultCode.SUCCESS
        
        return ResultCode.FAIL_EXECUTION

    def get_cheminfo(self):
        self.cheminfo = helpers.get_dataframe_from_csv(Tables().CHEM_INFO)

    def get_cas_nos(self):
        self.chem_mix = helpers.get_cas_nos(chem_mix=self.chem_mix, cheminfo=self.cheminfo)

    def get_molar_comp(self):
        if self.comp_is_moles:
            self.composition = helpers.normalize_fractions(self.composition)
            return
        mws = helpers.get_mws(chem_mix=self.chem_mix, cheminfo=self.cheminfo)
        self.composition = helpers.mol_fracts_from_mass_fracts(masses=self.composition, mws=mws)

    def set_state(self):
        self.state = State(pressure=self.press_pa, temperature=self.temp_k, liquid_fraction=None)
        self.state.mixture_modelling = MixtureModelling.MC_SINGLE_AEROSOL

    def set_material(self):
        if self.material is not None:
            return
        
        mat_comps = []
        for i in range(len(self.chem_mix)):
            mc = self.get_mat_comp(self.chem_mix[i])
            mc.mole_fraction = self.composition[i]
            mat_comps.append(mc)
        self.material = Material(name=Consts.MATERIAL_NAME, components=mat_comps)
        self.material.component_count = len(self.chem_mix)

    def get_mat_comp(self, chem) -> MaterialComponent:
        mat_id = helpers.vlookup_value_x_in_pandas_dataframe_df_in_col_y_get_data_in_column_z(chem, self.cheminfo, 'cas_no', 'mat_comp_id')
        mc = MaterialComponent(name=chem, mole_fraction=1)
        try:
            print('getting material')
            mc = get_component_by_id(mat_id)
        except Exception as e:
            raise Exception(Exception_Enum.CHEMICAL_MISSING_FROM_DATABASE)
        return mc

    def flash_wrapper(self):
        self.get_flash_result()


    def get_flash_result(self):
        print('flashing')
        flash = FlashCalculation(material=self.material, material_state=self.state)
        flashy:FlashResult = ResultCode.FAIL_EXECUTION
        try:
            flashy = flash.run()
        except:
            self.model_ok = False
            return
        if flashy != ResultCode.SUCCESS:

            self.error_msg = f'flash issues: {flash.messages}'
            print(f'flash issues: {flash.messages}')
            self.model_ok = False
            return
        
        self.flash_result:FlashResult = flash.flash_result
        
    def set_leak(self):
        self.leak = Leak(hole_diameter=self.diam_m, hole_height_fraction=0.0)
    
    def set_vessel(self):

        vessel = Vessel(state=self.state, material=self.material)

        vess_condit_lookup = {
            Phase.LIQUID: VesselConditions.PRESSURIZED_LIQUID_VESSEL,
            Phase.TWO_PHASE: VesselConditions.HOMOGENEOUS_VESSEL_TYPE,
            Phase.VAPOUR: VesselConditions.PURE_GAS
        }

        vessel.vessel_conditions = vess_condit_lookup[self.flash_result.fluid_phase]
        vessel.material = self.material
        vessel.diameter = 10
        vessel.height = 10
        vessel.shape = VesselShape.VERTICAL_CYLINDER
        vessel.liquid_fill_fraction_by_volume = 0.0
        if vessel.vessel_conditions == VesselConditions.PRESSURIZED_LIQUID_VESSEL:
            vessel.liquid_fill_fraction_by_volume = 0.99
            self.leak.hole_height_fraction = 0.98
        if vessel.vessel_conditions == 2:
            liq_mass = self.flash_result.liquid_mass_fraction
            liq_vol = liq_mass / self.flash_result.liquid_density
            vap_mass = 1 - liq_mass
            vap_vol = vap_mass / self.flash_result.vapour_density
            vessel.liquid_fill_fraction_by_volume = liq_vol / (liq_vol + vap_vol)
            self.leak.hole_height_fraction = vessel.liquid_fill_fraction_by_volume

        vessel.state = self.state

        self.vessel = vessel

    def disch_wrapper(self):
        # out_file = 'pws_chem_comp_ids.csv'
        # out_dict = {
        #     "name": self.material.components[0].name,
        #     "cas_id": self.material.components[0].casId,
        # }
        # if not self.get_discharge_data():
        #     out_file = 'errors_pws_chem_comp_ids.csv'
        #     out_dict['err_msg'] = 'Disp Failed'
        #     self.write_row_to_csv(out_dict, out_file)

        self.get_discharge_data()

    def get_discharge_data(self):
        vlc = VesselLeakCalculation(vessel=self.vessel, leak=self.leak, discharge_parameters=None)

        discharge_parameters = DischargeParameters()
        discharge_parameters.flash_at_orifice = FlashAtOrifice.FLASH_ALLOWED

        vlc.discharge_parameters = discharge_parameters
        vlc.leak = self.leak

        print('vessel leak calc')
        
        vlc_run = ResultCode.FAIL_EXECUTION

        try:
            vlc_run = vlc.run()
        except:
            self.model_ok = False
            return
        
        if vlc_run != ResultCode.SUCCESS:
            self.error_msg = f'discharge issue: {vlc.messages}'
            print(vlc.messages)
            self.model_ok = False
            return
            # sys.exit()

        self.discharge_result = vlc_run
        self.discharge_calculation = vlc

    def get_discharge_results(self):

        data = self.discharge_calculation
        cas_nos_and_mol_fracts_out = helpers.get_cas_nos_and_mol_fracts_from_material(data.exit_material, cheminfo=self.cheminfo)
        cas_nos = cas_nos_and_mol_fracts_out['cas_nos']
        molfs = cas_nos_and_mol_fracts_out['molfs']
        if len(data.discharge_records) == 0:
            self.data_dict = {}
            self.data = helpers.dict_to_json(self.data_dict)
            return

        dr_0:DischargeRecord = data.discharge_records[0]
        fin_state:State = dr_0.final_state
        fin_press_pa = fin_state.pressure
        fin_press_psig = (fin_press_pa / 101325 - 1) * 14.6959
        fin_temp_k = fin_state.temperature
        fin_temp_c = fin_temp_k - 273.15
        mass_flow_kg_s = dr_0.mass_flow
        mass_flow_kg_hr = mass_flow_kg_s * 3600
        mass_flow_lb_hr = mass_flow_kg_hr * Consts.LB_PER_KG
        pws_vapor_mass_fraction = 1 - fin_state.liquid_fraction
        gpp = Get_Phys_Props(chem_mix=cas_nos, molar_basis=True, chem_composition=molfs, temp_C=fin_temp_c, press_psig=fin_press_psig)
        gpp.run()

        py_lopa_flash_data = gpp.data_dict

        ans = thermo_pio.match_pylopa_liquid_fract_to_pws_return_adjusted_temperature_deg_k(vlc = self.discharge_calculation, py_lopa_flash_data=py_lopa_flash_data, cheminfo=self.cheminfo, log_handler=self.log_handler)

        adjusted_exit_temp_c = ans['temp_k'] - 273.15
        
        py_lopa_flash_data = ans['py_lopa_flash']

        self.data_dict = {
            'exit_temp_deg_c': fin_temp_c,
            'exit_press_psig': fin_press_psig,
            'mass_flow_kg_s': mass_flow_kg_s,
            'mass_flow_kg_hr': mass_flow_kg_hr,
            'mass_flow_lb_hr': mass_flow_lb_hr,
            'pws_vapor_mass_fraction': pws_vapor_mass_fraction,
            'downstream_flash_data': py_lopa_flash_data,
            'adjusted_exit_temp_c': adjusted_exit_temp_c,
            'upstream_flash_data': self.flash_result.__dict__
        }
        self.data = helpers.dict_to_json(self.data_dict)
