import copy
import numpy as np
import pandas as pd
from datetime import datetime as dt

from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts
from py_lopa.calcs.flattening import Flattening

cd = Consts().CONSEQUENCE_DATA

class Plotting_and_Debug_Data:

    def __init__(self, dispersion, chems = None, release_duration_sec = ''):
        self.dispersion = dispersion
        self.analysis_df = dispersion.analysis_df
        self.conc_pfls = dispersion.conc_profiles
        self.mi = dispersion.mi
        self.hazard_recs = []
        self.chems = chems
        self.debug_data = {}
        self.disp_plot = None
        self.plant_personnel_impact = None
        
        run_detail = f'rel_duration_{max(1, int(release_duration_sec))}_sec'

        conseq_recs_and_disp_plot = helpers.get_conc_records_and_dispersion_plot(cp_s = self.conc_pfls, chems = self.chems, run_detail=run_detail)
        self.debug_conc_records = conseq_recs_and_disp_plot['conc_records']
        self.debug_analysis_df = self.analysis_df.to_json()
        self.disp_plot = conseq_recs_and_disp_plot['dispersion_plot']
