import copy
import json
import pandas as pd

from py_lopa.calcs.consts import Consts, Wx_Enum
from py_lopa.calcs import helpers

cd = Consts().CONSEQUENCE_DATA

class All_Class_Results:

    def __init__(self, mi) -> None:
        
        bldgs = mi.bldgs

        self.mi = mi
        self.use_one_met_condition_worst_case=True
        if self.mi is not None:
            self.use_one_met_condition_worst_case = self.mi.USE_ONE_MET_CONDITION_WORST_CASE
        res = {
            Wx_Enum.NIGHT: {},
            Wx_Enum.DAY: {}
        }
        if self.use_one_met_condition_worst_case:
            res = {cd.WX_WORST_CASE: {}}

        self.bldgs = bldgs
        self.results = {
            cd.CLASS_ONSITE : copy.deepcopy(res),
            cd.CLASS_BLDG : copy.deepcopy(res),
            cd.CLASS_OFFSITE : copy.deepcopy(res)
        }

        self.prep_bldg_results()


    def prep_bldg_results(self):

        bldg_res_arr = []
        for bldg in self.bldgs:
            res_dict = {
                cd.KEYS_TARG_AND_TYPE_BLDG_NUM: bldg.num,
                cd.KEYS_TARG_AND_TYPE_BLDG_DIST_M: bldg.dist_m,
                cd.OCCUPANCY: bldg.occupancy,
                cd.OCC_NIGHT: bldg.nighttime_occupancy
            }
        
            bldg_res_arr.append(copy.deepcopy(res_dict))
        
        if self.use_one_met_condition_worst_case:
            wx_condits = [cd.WX_WORST_CASE]
        else:
            wx_condits = cd.WX_ALL_TYPES

        for wx in wx_condits:
            self.results[cd.CLASS_BLDG][wx] = copy.deepcopy(bldg_res_arr)


        
    def assessment(self, ca, haz_type, wx_enum):
        
        self.wx_enum = wx_enum
        self.ca = ca
        self.haz_type = haz_type

        self.set_onsite_and_offsite_results()
        
        self.set_bldg_results()

        # data structure for on-site:
        # { flash fire: {
        #       category: moderate, 
        #       impact_distance_m: 100,
        #       impact_area_m2: pd.NA
        #   },
        #   inhalation: {
        #       ... (same keys as ff) ...
        #   },
        # }
        # impact area reflects the zone impacted for serious and above.
        # impact distance is utilized for Minor and Moderate. 

        # data structure for offsite:
        # { 
        #   flash fire: moderate,
        #   inhalation: serious
        # }

        # building results are a list of dicts:
        # [
        #   {
        #       bldg_num: 18,
        #       occupancy: low,
        #       flash fire: moderate,
        #       inhalation: serious
        #   }
        # ]
    
    def set_onsite_and_offsite_results(self):

        on_off_res = self.ca.onsite_offsite_conseq_dict
        on = on_off_res[cd.CLASS_ONSITE]
        off = on_off_res[cd.CLASS_OFFSITE]
        self.results[cd.CLASS_ONSITE][self.wx_enum][self.haz_type] = on[self.wx_enum][self.haz_type]
        self.results[cd.CLASS_OFFSITE][self.wx_enum][self.haz_type] = off[self.wx_enum][self.haz_type]


    def set_bldg_results(self):

        bldgs = self.ca.mi.bldgs
        for i in range(len(bldgs)):
            results_in = bldgs[i].building_conseq_result_dict
            haz_res = results_in[self.wx_enum][self.haz_type]
            self.results[cd.CLASS_BLDG][self.wx_enum][i][self.haz_type] = haz_res


    def replace_all_na_values(self, thing):

        if isinstance(thing, dict):
            for k, v in thing.items():
                thing[k] = self.replace_all_na_values(v)
        elif isinstance(thing, list):
            for i in range(len(thing)):
                thing[i] = self.replace_all_na_values(thing[i])
        else:
            if pd.isna(thing):
                thing = cd.JSON_NULL
            
        return thing
            
            

