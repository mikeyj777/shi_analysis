from py_lopa.calcs.consts import Consts, Wx_Enum
from py_lopa.calcs import helpers

cd = Consts().CONSEQUENCE_DATA

class Interim_Results_to_Log_Handler:

    def __init__(self, release_duration_sec, mass_released_kg, wx_enum, results, haz_type, id_string='', log_handler=print) -> None:

# cd.OUTPUT_DICT_RELEASE_DURATION_SEC: max(1,int(actual_release_duration_sec)),
#                         cd.OUTPUT_DICT_MASS_RELEASED_KG: max(1,int(mass_released_kg)),
#                         cd.OUTPUT_DICT_HAZARD_RECS: acr_dict[haz].results,
        release_duration_min = release_duration_sec / 60
        self.release_duration_min = max(1, int(release_duration_min))
        self.mass_released_kg = max(1, mass_released_kg)
        self.haz_type = haz_type
        self.wx_enum = wx_enum
        self.results = results
        self.id_string = id_string
        self.log_hander = log_handler

    def output_to_handler(self):
        t = self.prep_output_message()
        self.log_hander(t)

    def prep_output_message(self):

        # output_dict = {
        #     cd.OUTPUT_DICT_RELEASE_DURATION_SEC: max(1,int(actual_release_duration_sec)),
        #     cd.OUTPUT_DICT_MASS_RELEASED_KG: max(1,int(mass_released_kg)),
        #     cd.OUTPUT_DICT_HAZARD_RECS: acr.results,
        # }

        haz = self.haz_type

        rel_durn_min = self.release_duration_min

        mass_released_kg = self.mass_released_kg
        haz_recs = self.results

        on_site = haz_recs[cd.CLASS_ONSITE]
        on_haz = on_site[self.wx_enum][haz]

        t = '\n'
        t += 'Run Details\n'
        t += self.id_string
        t += '\n'
        t += f'Release Duration: {rel_durn_min} min\n'
        t += f'Mass Released:  {mass_released_kg} kg\n'
        t += '\n\n'
        t += 'On-Site\n'
        t += f'\t{haz}\n'

        # inner_result = {
        #     cd.CAT_TITLE: pd.NA,
        #     cd.IMPACT_DISTANCE_M: pd.NA,
        #     cd.IMPACT_AREA_M2: pd.NA
        # }
        t += f'\t\tWeather Condition:{self.wx_enum}\n'
        t += f'\t\tCategory: {on_haz[cd.CAT_TITLE]}\n'
        t += f'\t\tImpacted Distance (m): {on_haz[cd.IMPACT_DISTANCE_M]}\n'
        t += f'\t\tImpacted Area (m2): {on_haz[cd.IMPACT_AREA_M2]}\n'
        t += f'\t\tRequired Area (m2): {on_haz[cd.REQUIRED_AREA_M2]}\n'
        t += f'\t\tProbability of Exposure: {on_haz[cd.PROBABILITY_OF_EXPOSURE]}\n'
        if haz == cd.HAZARD_TYPE_FLASH_FIRE:
            t += f'\t\tDistance to LFL (m): {on_haz[cd.DISTANCE_TO_LFL_M]}\n'
        t += '\n\n'
        
        # res_dict = {
        #         cd.KEYS_TARG_AND_TYPE_BLDG_NUM: bldg.num,
        #         cd.OCCUPANCY: bldg.occupancy,
        #         cd.HAZARD_TYPE_FLASH_FIRE: bldg_ff,
        #         cd.HAZARD_TYPE_INHALATION: bldg_inhal}


        t += 'Building Results\n'
        bldg_results = haz_recs[cd.CLASS_BLDG][self.wx_enum]

        for bldg in bldg_results:

            if self.wx_enum == Wx_Enum.NIGHT:
                occ_to_use = bldg[cd.OCC_NIGHT]
            else:
                occ_to_use = bldg[cd.OCCUPANCY]

            t += f'\tBuilding Number: {bldg[cd.KEYS_TARG_AND_TYPE_BLDG_NUM]}\n'
            t += f'\t\tDistance (m):  {bldg[cd.KEYS_TARG_AND_TYPE_BLDG_DIST_M]}\n'
            t += f'\t\tOccupancy:  {occ_to_use}\n'
            t += f'\t\t{haz}:  {bldg[haz]}\n'
            t += '\n'
        
        t += 'Off-Site\n'
        off = haz_recs[cd.CLASS_OFFSITE]
        off_haz = off[self.wx_enum][haz]
        t += f'\t{haz}:  {off_haz}\n'
        t += '\n\n'
        t += '---------------------------------------------\n\n'

        return t


