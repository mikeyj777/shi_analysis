import copy

import pandas as pd
import numpy as np

from py_lopa.calcs import helpers
from py_lopa.data.tables import Tables

class Phys_Props:

    def __init__(self, cas_no = None) -> None:
        self.cas_no = cas_no
        self.lcp = []
        self.icp = []
        self.hvp = []
        self.tc = None
        self.nbp = None

        # redundant calls to get data from csvs.  
        # however, since I can't use Static variables, this feels cleaner than keeping these values out of the object and then reapplying.
        self.dippr_consts_df = helpers.get_dataframe_from_csv(Tables().DIPPR_CONSTANTS)
        self.e_bal_phys_props_df = helpers.get_dataframe_from_csv(Tables().ENERGY_BALANCE_PHYS_PROPS)


    def get_property_values_and_constants(self, temp_k = None):
        
        # populate a dictionary of nbp, tc, and all needed coefficients for this cas_number

        cas_no = self.cas_no

        const_prop_ids_to_get = ['nbp', 'tc']
        
        for const_prop_id in const_prop_ids_to_get:
            curr_si_phys_prop_val = getattr(self, const_prop_id)
            if curr_si_phys_prop_val is None:
                # this returns a list of potential physical properties.  for constants, the tool is currently averaging over all possibilites
                data = self.get_property_value_or_coeffs_from_dataframe(property_id=const_prop_id, cas_no=cas_no, dataframe=self.dippr_consts_df)
                data_0 = data[0]
                const = data_0['constant_val']
                setattr(self, const_prop_id, const)

        coeff_prop_ids_to_get = ['hvp', 'lcp', 'icp']
        for coeff_prop_id in coeff_prop_ids_to_get:
            curr_datasets_for_prop_id = getattr(self, coeff_prop_id)
            if len(curr_datasets_for_prop_id) > 0:
                continue
            data = self.get_property_value_or_coeffs_from_dataframe(property_id=coeff_prop_id, cas_no=cas_no, dataframe=self.e_bal_phys_props_df)
            setattr(self, coeff_prop_id, data)
    
    def get_property_value_or_coeffs_from_dataframe(self, property_id, cas_no, dataframe):

        df:pd.DataFrame = dataframe

        ans = {
            'cas_no': cas_no,
            'property_id':  property_id,
            'constant_val':  None,
            'coefficients': None,
            'min_t': None,
            'max_t': None,
            'eqn_id': None,
        }

        # if getting constant value, it will not be from the data table with the coefficient columns.

        if 'coeff_a' not in df.columns:
            prop_id_df = self.dippr_consts_df[self.dippr_consts_df['property_id'] == property_id]
            prop_id_data_for_cas_no = prop_id_df[prop_id_df['cas_no'] == cas_no]
            if len(prop_id_data_for_cas_no) > 1:
                prop_id_val = 0
                for i in range(len(prop_id_data_for_cas_no)):
                    r = prop_id_data_for_cas_no.iloc[i]
                    prop_id_val_new = helpers.get_data_from_pandas_series_element(r['value'])
                    prop_id_val = (prop_id_val_new + prop_id_val) / (i+1)
            else:
                prop_id_val = helpers.get_data_from_pandas_series_element(prop_id_data_for_cas_no['value'])
            
            ans['constant_val'] = prop_id_val

            return [ans]
        
        prop_id_df = self.e_bal_phys_props_df[self.e_bal_phys_props_df['property_id'] == property_id]
        prop_id_data_for_cas_no = prop_id_df[prop_id_df['cas_no'] == cas_no]

        list_of_props = []
        for _, data in prop_id_data_for_cas_no.iterrows():
            a = copy.deepcopy(ans)
            coeffs = helpers.get_consts(data)
            min_t = helpers.get_data_from_pandas_series_element(data['min_t'])
            max_t = helpers.get_data_from_pandas_series_element(data['max_t'])
            eqn_id = helpers.get_data_from_pandas_series_element(data['eqn_id'])

            a['coefficients'] = coeffs
            a['min_t'] = max_t
            a['max_t'] = min_t
            a['eqn_id'] = eqn_id

            list_of_props.append(a)

        return list_of_props

    def get_closest_property_dataset_to_temp(self, prop_id, temp_k):
        
        data_list = getattr(self, prop_id)

        if len(data_list) == 1:
            return data_list[0]

        diff_bet_closest_low_and_t_min = np.inf
        diff_bet_closest_high_and_t_max = np.inf
        best_score_idx = 0
        best_idx = 0
        for i in range(len(data_list)):
            score_idx = 0
            r = data_list[i]
            min_t = r['min_t']
            max_t = r['max_t']
            if (temp_k >= min_t and temp_k <= max_t):
                return r
            diff_low = abs(min_t - temp_k)
            diff_high = abs(max_t - temp_k)
            if diff_low < diff_bet_closest_low_and_t_min:
                diff_bet_closest_low_and_t_min = diff_low
                score_idx += 1
            if diff_high < diff_bet_closest_high_and_t_max:
                diff_bet_closest_high_and_t_max = diff_high
                score_idx += 1
            if score_idx > best_score_idx:
                best_score_idx = score_idx
                best_idx = i

        return data_list[best_idx]