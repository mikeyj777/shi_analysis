import csv
import copy
import math
import random
import numpy as np
import pandas as pd
from scipy.interpolate import griddata
from scipy import integrate
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from pypws.calculations import DispersionCalculation, LateExplosionCalculation, DistancesAndFootprintsToConcentrationLevelsCalculation
from pypws.entities import ExplosionConfinedVolume, DispersionOutputConfig, ExplosionOutputConfig, ExplosionParameters
from pypws.enums import Resolution, SpecialConcentration, MEConfinedMethod, ResultCode

from py_lopa.calcs import helpers
from py_lopa.calcs.integrator import Integrator
from py_lopa.data.tables import Tables
from py_lopa.calcs.geospatial import distance_in_meters_between_lat1_long1_and_lat2_long_2
from py_lopa.calcs.tno_multienergy_blast_correlations import get_psc_given_blast_strength_class_and_scaled_radius
from py_lopa.classes.building import Building
from py_lopa.classes.source_input import Source_Input
from py_lopa.calcs.energy_balance import Energy_Balance

class VCE:

    def __init__(self, phast_dispersion = None, save_pickles = False, logging = None) -> None:
        self.logging = logging
        self.zxys_df = {}
        self.phast_dispersion = phast_dispersion
        if save_pickles:
            self.save_pickles()
        self.targ_concs = []
        self.dispersionCalculation = None
        self.mi = None
        self.flash_data = None
        if self.phast_dispersion is not None:
            lfl = self.phast_dispersion.ep_conc
            self.targ_concs = [lfl]
            self.dispersionCalculation = phast_dispersion.dispersionCalculation
            self.mi = phast_dispersion.mi
            self.flash_data = self.phast_dispersion.chems.flash_data
        self.flammable_mass_g = None
        self.flammable_mass_results = None
        self.max_dw_extent = None
        self.flammable_envelope_list_of_dicts = []
        self.flammable_envelope_df = {}
        self.congested_volumes = []
    
    
    def get_overall_flammable_envelope_and_maximum_downwind_extent(self):
        self.get_conc_targets_between_lfl_and_pure_conc()
        resp = self.run_dispersion_model_inside_flammable_envelope()
        
        if resp != ResultCode.SUCCESS:
            self.phast_dispersion.mi.LOG_HANDLER('VCE flammable envelope model did not complete successfully')
            return
        self.phast_dispersion.mi.LOG_HANDLER('VCE flammable envelope model completed OK')

        self.parse_flam_env_contour_points()

        return {
            'flammable_envelope_list_of_dicts': self.flammable_envelope_list_of_dicts,
            'maximum_downwind_extent': self.max_dw_extent,
            'flash_data': self.flash_data,
        }
    
    def save_pickles(self):
        helpers.save_object_as_pickle_return_path_and_file_name(self.phast_dispersion, descr='p_disp', out_dir='../vce_testing/', use_time_stamp=False)
    
    def get_conc_targets_between_lfl_and_pure_conc(self):
        # concentrations exponentially increasing from lfl to pure conc over 6 values:  1e6 = lfl * factor^6 
        lfl = self.targ_concs[0]
        self.targ_concs = np.linspace(lfl, 0.99, 10).tolist()
        low_end_concs = np.linspace(lfl, self.targ_concs[1], 10).tolist()
        self.targ_concs.extend(low_end_concs)
        self.targ_concs.sort()
        

    def run_dispersion_model_inside_flammable_envelope(self):
        self.phast_dispersion.run_footprint_models_for_vce(self.targ_concs)

        return self.phast_dispersion.distancesAndFootprintsCalc.result_code
    
    def parse_flam_env_contour_points(self):
        dists_and_concs:DistancesAndFootprintsToConcentrationLevelsCalculation = self.phast_dispersion.distancesAndFootprintsCalc
        n_contour_points = dists_and_concs.n_contour_points
        data = []
        cp_idx_start = 0
        cps = dists_and_concs.contour_points
        for i in range(len(n_contour_points)):
            if n_contour_points[i] == 0:
                continue
            dispOutputCfg:DispersionOutputConfig = dists_and_concs.dispersion_output_configs[i]
            conc = dispOutputCfg.concentration
            if conc is None:
                conc = 0
            cp_count = n_contour_points[i]
            curr_cp_range = cps[cp_idx_start:cp_idx_start+cp_count]
            for cp in curr_cp_range:
                x = cp.x
                y = cp.y
                z = cp.z
                data.append({
                    'x': x,
                    'y': y,
                    'z': z,
                    'conc_ppm': conc * 1e6
                })
            cp_idx_start += cp_count
        
        if len(data) == 0:
            data.append({
                'x': 0,
                'y': 0,
                'z': 0,
                'conc_ppm': 0
            })
        df = pd.DataFrame(data)
        
        df = df[(df['x'] > -10000) & (df['x'] < 10000)]

        # concGm3 = concPpm * mWt / 24450
        ys = np.array(self.flash_data['ys'])
        if ys.sum() == 0:
            ys = np.array(self.flash_data['k_times_zi'])
            if ys.sum() > 0:
                ys /= ys.sum()
        mws = np.array(self.flash_data['mws'])
        ave_mw_vap = ys.dot(mws.T)
        df['conc_g_m3'] = df['conc_ppm'] * ave_mw_vap / 24450
        self.flammable_envelope_df = df
        self.flammable_envelope_list_of_dicts = df.to_dict(orient='records')
        x_min = df['x'].min()
        x_max = df['x'].max()
        self.max_dw_extent=max(abs(x_min), abs(x_max))

    def get_flammable_mass(self, x_min = None, x_max = None, y_min = None, y_max = None, z_min = None, z_max = None, flammable_envelope_list_of_dicts = None, cv = None, stoich_moles_o2_to_fuel = None, flash_data = None):
        
        # stoich ratio is provided and we can either use the flash data provided as argument or the flash data stored as a property
        if stoich_moles_o2_to_fuel is not None and (flash_data is not None or self.flash_data is not None):  

            if flash_data is None:
                flash_data = self.flash_data

            self.flammable_mass_g = self.get_flammable_mass_from_stoich(stoich_moles_o2_to_fuel=stoich_moles_o2_to_fuel, flash_data=flash_data, x_min=x_min, x_max=x_max, y_min=y_min, y_max=y_max, z_min=z_min, z_max=z_max)
            return {
                'flammable_mass_g': self.flammable_mass_g,
                'flammable_mass_results': None,
                'error': None,
            }
        
        if stoich_moles_o2_to_fuel is not None and flash_data is None and self.flash_data is None:
            print("stoichiometric ratio data provided, but flash data not available.  will attempt to use the flammable envelope method.")

        if flammable_envelope_list_of_dicts is None:
            flammable_envelope_df = self.flammable_envelope_df
        else:
            flammable_envelope_df = pd.DataFrame(flammable_envelope_list_of_dicts)
        
        if len(flammable_envelope_df) == 0:
            raise  {
                'flammable_mass_g': None,
                'flammable_mass_results': None,
                'error': "Flammable Envelope Not Provided",
            }

        integrator = Integrator()
        integrator.load_data(flammable_envelope_df)
        if cv is not None:
            if 'dims' in cv:
                dims = cv['dims']
                if x_min is None:
                    x_min = dims['xMin']
                if x_max is None:
                    x_max = dims['xMax']
                if y_min is None:
                    y_min = dims['yMin']
                if y_max is None:
                    y_max = dims['yMax']
                if z_min is None:
                    z_min = dims['zMin']
                if z_max is None:
                    z_max = dims['zMax']

        results = integrator.integrate(x_min=x_min, x_max=x_max, y_min=y_min, y_max=y_max, z_min=z_min, z_max=z_max)
        self.flammable_mass_g = results['total_mass_g']
        self.flammable_mass_results = results
        return {
            'flammable_mass_g': self.flammable_mass_g,
            'flammable_mass_results': self.flammable_mass_results,
            'error': None,
        }
    
    def get_flammable_mass_from_stoich(self, stoich_moles_o2_to_fuel, flash_data, x_min, x_max, y_min, y_max, z_min, z_max):
        x = stoich_moles_o2_to_fuel
        vol_cong = (x_max - x_min) * (y_max - y_min) * (z_max - z_min)
        vol_cong = abs(vol_cong)
        vol_fract_fuel = 1 / (1 + x + 79 / 21 * x) # 1 mol of fuel in a stoich amount of o2 plus the n2 in air
        vol_fuel = vol_fract_fuel * vol_cong
        temp_k = self.get_mix_temp(vol_fract_fuel, flash_data)
        mol_fuel_g = 1 * vol_fuel / (0.00289783) / temp_k # R [atm * ft3 / g-mol / deg K]
        ave_mw_vap_fuel = flash_data['ave_mw_vap']
        mass_fuel_g = ave_mw_vap_fuel * mol_fuel_g
        return mass_fuel_g


    def get_mix_temp(self, vol_fract_fuel, flash_data):
        ys_mass = []
        ys = flash_data['ys']
        if sum(ys) == 0:
            ys = flash_data['k_times_zi']
            if sum(ys) != 0:
                ys = np.array(ys)
                ys /= ys.sum()
        mws = flash_data['mws']
        for i in range(len(ys)):
            y = ys[i]
            mw = mws[i]
            ys_mass.append(y * mw)
        ys_mass = np.array(ys_mass)
        if ys_mass.sum() > 0:
            ys_mass /= ys_mass.sum()

        # nudge temperature up to ensure fuel is vapor in model.
        temp_k = flash_data['temp_k'] + 0.01
        ave_mw_vap_fuel = flash_data['ave_mw_vap']
        moles_fuel_per_ft3_mixture_kmol = 1 * vol_fract_fuel / 2.89783 / temp_k # atm.ft3/kg-mol/deg K
        mass_fuel_kg = moles_fuel_per_ft3_mixture_kmol * ave_mw_vap_fuel
        
        cheminfo = helpers.get_cheminfo()
        si_fuel = Source_Input(description='fuel', mass_composition=ys_mass, chem_mix=flash_data['chem_mix'], temp_k=flash_data['temp_k'] + 0.01, press_pa=101325, mass_flow_kg_s=mass_fuel_kg, cheminfo=cheminfo)
        si_fuel.populate_flash_results()

        moles_air_per_ft3_mixture_kmol = 1 * (1-vol_fract_fuel) / 2.89783 / temp_k
        mass_air_kg = moles_air_per_ft3_mixture_kmol * 28.96

        si_air = Source_Input(description='air', mass_composition=[1], chem_mix=['132259-10-0'], temp_k=298.15, press_pa=101325, mass_flow_kg_s=mass_air_kg, cheminfo=cheminfo)
        si_air.populate_flash_results()

        si_combined = self.source_input_for_fuel_and_air_mixture(si_fuel=si_fuel, si_air=si_air, cheminfo=cheminfo)
        e_bal = Energy_Balance(si=si_combined)
        e_bal.set_temp_where_combined_enthalpy_is_zero()
        si_combined = e_bal.si
        temp_k_mix = si_combined.temp_k
        return temp_k_mix




    def source_input_for_fuel_and_air_mixture(self, si_fuel:Source_Input, si_air:Source_Input, cheminfo = None):

        source_inputs = [si_fuel, si_air]
        
        component_rates = {}
        combined_output = Source_Input(cheminfo=cheminfo)
        combined_output.description = 'combined air, and fuel'
        combined_output.chem_mix = si_fuel.chem_mix + ['132259-10-0']
        combined_output.mass_composition = np.zeros(len(combined_output.chem_mix))
        
        si:Source_Input
        for si in source_inputs:
            combined_output.mass_flow_kg_s += si.mass_flow_kg_s
            for i in range(len(si.chem_mix)):
                component_mass_rate = si.mass_composition[i] * si.mass_flow_kg_s
                if si.chem_mix[i] not in component_rates:
                    component_rates[si.chem_mix[i]] = component_mass_rate
                    continue
                component_rates[si.chem_mix[i]] += component_mass_rate
        
        for i in range(len(combined_output.chem_mix)):
            if combined_output.mass_flow_kg_s > 0:
                combined_output.mass_composition[i] = component_rates[combined_output.chem_mix[i]] / combined_output.mass_flow_kg_s
        
        combined_output.mass_composition = combined_output.mass_composition.tolist()

        combined_output.concatenate_component_data_for_mixed_stream(source_inputs=source_inputs)

        return combined_output



    def plot_flammable_envelope(self):
        df = self.flammable_envelope_df
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')

        sc = ax.scatter(df['x'], df['y'], df['z'], c=df['conc_ppm'], cmap='viridis')

        plt.colorbar(sc)
        ax.set_xlabel('X Axis')
        ax.set_ylabel('Y Axis')
        ax.set_zlabel('Z Axis')

        plt.show()

    def get_mixture_reactivity_0_low_1_med_2_high(self, flash_data = None):
        if flash_data is None:
            flash_data = self.flash_data
        if flash_data is None:
            return -1
        burning_velocity_df = helpers.get_dataframe_from_csv(Tables().LAMINAR_BURNING_VELOCITY_DATA)
        chem_mix = flash_data['chem_mix']
        ys = flash_data['ys']
        if sum(ys) == 0:
            ys = flash_data['k_times_zi']
            ys = np.array(ys)
            if ys.sum() != 0:
                ys /= ys.sum()
        burn_veloc_denom = 0
        mixture_burning_velocity_m_s = 0
        for i in range(len(chem_mix)):
            row = burning_velocity_df[burning_velocity_df['cas'] == chem_mix[i]]
            if len(row) == 0:
                continue
            burning_veloc_m_s = helpers.get_data_from_pandas_series_element(row['burning_velocity_m_s'])
            if burning_veloc_m_s == 0:
                continue
            burn_veloc_denom += ys[i]/burning_veloc_m_s
        if burn_veloc_denom > 0:
            mixture_burning_velocity_m_s = 1 / burn_veloc_denom
        reactivity = 1
        if mixture_burning_velocity_m_s >= 0.75:
            reactivity = 2
        if mixture_burning_velocity_m_s < 0.45:
            reactivity = 0
        return reactivity
        
    def get_blast_strength_for_congested_volume(self, congested_volume, reactivity):
        """
        Basis - Table 5.3 Initial Blast strength index - TNO Yellow Book, p. 510

        Determine blast strength class based on reactivity, congestion level, and confinement.
        
        Parameters:
        - reactivity: int (0=Low, 1=Medium, 2=High)
        - congestion_level: int (0=No, 1=Low, 2=High)
        - is_indoors: bool (True=Confined, False=Unconfined)
        
        Returns:
        - int: The blast strength class (higher end of the range)
        """
        is_indoors = congested_volume['isIndoors']
        congestion_level = congested_volume['congestionLevel']
        
        
        # High Reactivity (2)
        if reactivity == 2:
            # High Congestion (2)
            if congestion_level == 2:
                if is_indoors:  # Confined
                    return 10  # Class 7-10
                else:  # Unconfined
                    return 9  # Class 7-10
            # Low Congestion (1)
            elif congestion_level == 1:
                if is_indoors:  # Confined
                    return 7   # Class 5-7
                else:  # Unconfined
                    return 6   # Class 4-6
            # No Congestion (0)
            else:
                if is_indoors:  # Confined
                    return 6   # Class 4-6
                else:  # Unconfined (this case isn't explicitly in the table)
                    return 5   # Class 4-5 (based on row 8, assuming confined)
        
        # Medium Reactivity (1) - interpolated
        elif reactivity == 1:
            # High Congestion (2)
            if congestion_level == 2:
                if is_indoors:  # Confined
                    return 9   # Between class 7-10
                else:  # Unconfined
                    return 8   # Between class 7-10
            # Low Congestion (1)
            elif congestion_level == 1:
                if is_indoors:  # Confined
                    return 6   # Between class 5-7
                else:  # Unconfined
                    return 5   # Between class 4-6
            # No Congestion (0)
            else:
                if is_indoors:  # Confined
                    return 5   # Between class 4-6
                else:  # Unconfined
                    return 4   # Between class 1-4
        
        # Low Reactivity (0)
        else:
            # High Congestion (2)
            if congestion_level == 2:
                if is_indoors:  # Confined
                    return 7   # Class 5-7
                else:  # Unconfined
                    return 5   # Class 4-5
            # Low Congestion (1)
            elif congestion_level == 1:
                if is_indoors:  # Confined
                    return 5   # Class 3-5
                else:  # Unconfined
                    return 3   # Class 2-3
            # No Congestion (0)
            else:
                if is_indoors:  # Confined
                    return 2   # Class 1-2
                else:  # Unconfined
                    return 1   # Class 1

    def get_heat_of_combustion_J(self, flash_data, flammable_mass_g):
        ys = np.array(flash_data['ys'])
        # if subcooled, utilize the thermo relation between k (psat / p) * liquid conc to get ys, then normalize.
        if ys.sum() == 0:
            ys = np.array(flash_data['k_times_zi'])
            if ys.sum() > 0:
                ys /= ys.sum()
        # combustion in vapor phase.  if no vapor phase exists, return 0 for combustion energy.
        if ys.sum == 0:
            return 0
        mws = np.array(flash_data['mws'])
        chem_mix = flash_data['chem_mix']
        ave_mw_vap = ys.dot(mws.T)
        df = helpers.get_dataframe_from_csv(Tables().DIPPR_CONSTANTS)
        h_comb_j_kmol_total = 0
        for i in range(len(chem_mix)):
            h_comb_j_kmol_element = df[(df['cas_no'] == chem_mix[i]) & (df['property_id'] == 'hcom')]
            h_comb_j_kmol = h_comb_j_kmol_element['value'].max()
            h_comb_j_kmol_total += h_comb_j_kmol * ys[i]
        h_comb_j_kg_total = h_comb_j_kmol_total / ave_mw_vap
        h_comb_j = abs(h_comb_j_kg_total * flammable_mass_g / 1000)
        return h_comb_j

    def get_blast_overpressures_at_buildings_from_congested_volumes_store_highest_pressure_at_each_building_return_updated_buildings(self, buildings, congested_volumes, flash_data = None, bldg_location_for_testing = None):
        if flash_data is None:
            flash_data = self.flash_data
        if flash_data is None:
            return buildings
        reactivity = self.get_mixture_reactivity_0_low_1_med_2_high(flash_data=flash_data)
        updated_bldgs = copy.deepcopy(buildings)
        for cv in congested_volumes:
            flammable_mass_g = cv['flammableMassG']
            if flammable_mass_g == 0:
                continue
            h_comb_j = self.get_heat_of_combustion_J(flash_data, flammable_mass_g)
            blast_strength_class = self.get_blast_strength_for_congested_volume(congested_volume=cv, reactivity=reactivity)
            cv_position = cv['position']
            lat1 = cv_position['lat']
            lng1 = cv_position['lng']
            for bldg in updated_bldgs:
                if isinstance(bldg, Building):
                    bldg = vars(bldg)
                if 'location' not in bldg:
                    if bldg_location_for_testing is not None:
                        bldg['location'] = bldg_location_for_testing
                    else:
                        bldg['location'] = cv_position
                bldg_position = bldg['location']
                lat2 = bldg_position['lat']
                lng2 = bldg_position['lng']
                dist_m_from_cv_to_bldg = distance_in_meters_between_lat1_long1_and_lat2_long_2(lat1, lng1, lat2, lng2)
                scaled_r = dist_m_from_cv_to_bldg / (h_comb_j / 101325) ** (1/3) # eqn 5.2 in TNO Yellow Book - p. 507
                scaled_p = get_psc_given_blast_strength_class_and_scaled_radius(tnoClass=blast_strength_class, scaled_radius=scaled_r)
                p_Pa_side_on = scaled_p * 101325 # yellow book eqn 5.3
                p_Pa_side_on_and_reflected = p_Pa_side_on * 2
                overpressure_psi = p_Pa_side_on_and_reflected * 14.6959 / 101325
                if 'max_overpressure_psi' not in bldg:
                    bldg['max_overpressure_psi'] = overpressure_psi
                
                bldg['max_overpressure_psi'] = max(bldg['max_overpressure_psi'], overpressure_psi)
        
        return updated_bldgs



        



