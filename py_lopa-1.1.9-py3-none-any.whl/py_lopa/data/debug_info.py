from datetime import datetime as dt

class Debug_Info:
    current_version = '1.0.0'
    t0 = dt(1970, 1, 1)