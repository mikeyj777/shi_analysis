class Color_Data():

    green = {
        'id': 'green',
        'line_color': 'ff00aa55',
        'poly_color': 'b300aa55'
    }

    yellow = {
        'id': 'yellow',
        'line_color': 'ff7fffff',
        'poly_color': 'b37fffff'
    }

    red = {
        'id': 'red',
        'line_color': 'ff0000ff',
        'poly_color': 'b30000ff'
    }

    pink = {
        'id': 'pink',
        'line_color': 'ffcd99f6',
        'poly_color': 'b3cd99f6'
    }

    all_color_dicts = [
        green,
        yellow,
        red,
        pink,

    ]
